import { prisma } from '@/lib/prisma';
import { opClient } from '@/services/opmanager/client';
import { broadcaster, BroadcastEvent } from '@/services/broadcast';
import { DeviceStatus } from '@prisma/client';

// Process devices in batches to control concurrency
// 减少批次大小以避免同时发送过多请求导致OpManager超时
const BATCH_SIZE = 5; // 从10减少到5，降低并发压力
const BATCH_DELAY_MS = 1000; // 批次之间延迟1秒

// Helper to chunk array without external dependency
function chunkArray<T>(array: T[], size: number): T[][] {
    const result: T[][] = [];
    for (let i = 0; i < array.length; i += size) {
        result.push(array.slice(i, i + size));
    }
    return result;
}

export class MetricCollector {
    async collectMetrics() {
        console.log('📊 Starting Metric Collection...');
        try {
            // Get monitored & reachable devices with their names
            /**
             * IMPORTANT: ONLINE 概念（避免后续逻辑混乱）
             *
             * WARNING/ERROR 不是“离线”，而是“在线但有故障/告警”——仍应继续拉取性能数据。
             * 只有：
             * - OFFLINE（OpManager Down：不可达/不可 Ping）
             * - UNMANAGED（OpManager UnManaged：未纳入监控）
             * 才应跳过进一步采集，避免无意义请求导致超时/卡住。
             */
            const devices = await prisma.device.findMany({
                where: {
                    isMonitored: true,
                    status: { notIn: [DeviceStatus.OFFLINE, DeviceStatus.UNMANAGED] },
                },
                select: { id: true, name: true }
            });
            const timestamp = new Date();

            let successCount = 0;
            const metricsToInsert: any[] = [];
            
            // Split devices into batches
            const batches = chunkArray(devices, BATCH_SIZE);

            for (let i = 0; i < batches.length; i++) {
                const batch = batches[i];
                
                // 批次之间添加延迟，避免连续请求导致OpManager过载
                if (i > 0) {
                    await new Promise(resolve => setTimeout(resolve, BATCH_DELAY_MS));
                }
                
                // Process batch in parallel
                await Promise.all(batch.map(async (device) => {
                    try {
                        // Fetch device summary using device NAME (not ID)
                        // 添加重试机制，最多重试2次
                        let summary = null;
                        let retries = 2;
                        while (retries >= 0 && !summary) {
                            try {
                                summary = await opClient.getDeviceSummary(device.name);
                                break;
                            } catch (error: any) {
                                if (retries > 0 && (error.code === 'ECONNABORTED' || error.message?.includes('timeout'))) {
                                    console.warn(`⚠️ Timeout fetching metrics for ${device.name}, retrying... (${retries} retries left)`);
                                    retries--;
                                    await new Promise(resolve => setTimeout(resolve, 2000)); // 重试前等待2秒
                                } else {
                                    throw error; // 非超时错误直接抛出
                                }
                            }
                        }

                        if (!summary) {
                            // console.debug(`ℹ️ No summary returned for ${device.name}`); // Reduce noise
                            return;
                        }

                        // Extract metrics safely from dials or summary fields
                        // OpManager Summary often has direct fields or a 'dials' array
                        let cpu = 0;
                        let mem = 0;
                        let disk = 0;

                        if (summary.dials && Array.isArray(summary.dials)) {
                            const cpuDial = summary.dials.find((d: any) => d.displayName?.includes('CPU'));
                            const memDial = summary.dials.find((d: any) => d.displayName?.includes('Memory'));
                            const diskDial = summary.dials.find((d: any) => d.displayName?.includes('Disk'));
                            
                            if (cpuDial) cpu = parseFloat(cpuDial.value);
                            if (memDial) mem = parseFloat(memDial.value);
                            if (diskDial) disk = parseFloat(diskDial.value);
                        } else {
                            // Fallback: try direct properties if API structure differs
                            cpu = parseFloat(summary.cpuUtilization || summary.cpu || '0');
                            mem = parseFloat(summary.memoryUtilization || summary.mem || '0');
                        }

                        const metricData = {
                            deviceId: device.id,
                            timestamp,
                            cpuUsage: isNaN(cpu) ? 0 : cpu,
                            memoryUsage: isNaN(mem) ? 0 : mem,
                            diskUsage: isNaN(disk) ? 0 : disk,
                            responseTime: parseFloat(summary.responseTime || '0'),
                            packetLoss: parseFloat(summary.packetLoss || '0'),
                        };

                        metricsToInsert.push(metricData);

                        // Broadcast update immediately for real-time feel
                        await broadcaster.emit(`device:${device.id}`, BroadcastEvent.METRICS_UPDATE, {
                            deviceId: device.id,
                            metrics: metricData
                        });

                        successCount++;
                    } catch (deviceError: any) {
                        // 只记录非超时错误，超时错误已在重试逻辑中记录
                        if (!deviceError.code || deviceError.code !== 'ECONNABORTED') {
                            console.error(`❌ Failed to collect metrics for ${device.name}:`, deviceError.message || deviceError);
                        }
                    }
                }));
            }

            // Bulk insert all collected metrics
            if (metricsToInsert.length > 0) {
                await prisma.deviceMetric.createMany({
                    data: metricsToInsert
                });
            }

            console.log(`✅ Collected metrics for ${successCount}/${devices.length} devices.`);
        } catch (error) {
            console.error('❌ Metric Collection Failed:', error);
        }
    }
}

export const metricCollector = new MetricCollector();
