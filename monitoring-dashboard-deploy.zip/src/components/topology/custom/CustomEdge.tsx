import React, { memo } from 'react';
import { EdgeProps, getSmoothStepPath, EdgeLabelRenderer } from 'reactflow';

const CustomEdge = ({
  id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  style = {},
  markerEnd,
  data,
}: EdgeProps) => {
  const [edgePath, labelX, labelY] = getSmoothStepPath({
    sourceX,
    sourceY,
    targetX,
    targetY,
  });

  // OPM 链接状态: 1/2 关闭/停止→红, 3 其他→黄, 4/7 取消管理→灰, 5 正常→蓝
  const s = String((data as any)?.status ?? '5');
  const edgeColor =
    s === '1' || s === '2' ? '#ef4444' : s === '3' ? '#eab308' : s === '4' || s === '7' ? '#6b7280' : '#3b82f6';

  return (
    <>
      <path
        id={id}
        style={{
          ...style,
          strokeWidth: 2,
          stroke: edgeColor,
          opacity: 0.8
        }}
        className="react-flow__edge-path"
        d={edgePath}
        markerEnd={markerEnd}
      />
      <EdgeLabelRenderer>
        <div
          style={{
            position: 'absolute',
            transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
            pointerEvents: 'all',
          }}
          className="bg-[#0a1929]/90 backdrop-blur-md px-2 py-1 rounded border border-blue-400/30 shadow-lg"
        >
          <div className="flex flex-col items-center">
            <span className="text-[9px] font-semibold text-white font-mono tracking-tighter">
              {data?.inTraffic && String(data.inTraffic).trim() ? data.inTraffic : '—'}
            </span>
          </div>
        </div>
      </EdgeLabelRenderer>
    </>
  );
};

export default memo(CustomEdge);
