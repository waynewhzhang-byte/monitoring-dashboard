import React, { memo } from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { Server, Shield, Network, Monitor, Router, Database } from 'lucide-react';

const CustomNode = ({ data, selected }: NodeProps) => {
  const getIcon = () => {
    const type = data.type?.toLowerCase() || '';
    // Match reference style: blue/white color scheme
    const iconColor = '#60a5fa'; // Light blue matching reference
    if (type.includes('firewall')) return <Shield className="w-10 h-10 text-white" />;
    if (type.includes('router')) return <Router className="w-10 h-10 text-white" />;
    if (type.includes('switch')) return <Network className="w-10 h-10 text-white" />;
    if (type.includes('server')) return <Server className="w-10 h-10 text-white" />;
    if (type.includes('database')) return <Database className="w-10 h-10 text-white" />;
    return <Monitor className="w-10 h-10 text-white" />;
  };

  const statusColor = data.status === 'ERROR' ? '#f43f5e' : 
                      data.status === 'WARNING' ? '#f59e0b' : 
                      '#10b981';

  // Match reference style: blue/white color scheme, cleaner design
  const getNodeColor = () => {
    const type = data.type?.toLowerCase() || '';
    if (type.includes('firewall')) return '#3b82f6'; // Blue for firewall
    if (type.includes('router')) return '#3b82f6'; // Blue for router
    if (type.includes('switch')) return '#3b82f6'; // Blue for switch
    if (type.includes('server')) return '#3b82f6'; // Blue for server
    return '#60a5fa'; // Light blue default
  };

  return (
    <div className="flex flex-col items-center group">
      <Handle type="target" position={Position.Top} className="!bg-blue-500/50 !w-2 !h-2" />
      
      <div className={`relative transition-all duration-300 ${selected ? 'scale-105' : 'hover:scale-102'}`}>
        {/* Icon Container - matching reference style */}
        <div 
          className="relative bg-blue-500/20 backdrop-blur-sm rounded-lg border-2 p-3 shadow-lg"
          style={{ borderColor: getNodeColor(), backgroundColor: 'rgba(59, 130, 246, 0.15)' }}
        >
          <div>
            {getIcon()}
          </div>
          
          {/* Status Dot - simplified */}
          <div 
            className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full border-2 border-[#0a1929]"
            style={{ backgroundColor: statusColor }}
          />
        </div>
      </div>

      {/* Label - white text matching reference */}
      <div className="mt-2 flex flex-col items-center max-w-[120px]">
        <span className="text-xs font-semibold text-white text-center leading-tight whitespace-normal">
          {data.label}
        </span>
      </div>

      <Handle type="source" position={Position.Bottom} className="!bg-blue-500/50 !w-2 !h-2" />
    </div>
  );
};

export default memo(CustomNode);
