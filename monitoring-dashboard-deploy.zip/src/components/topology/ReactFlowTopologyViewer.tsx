'use client';

import React, { useCallback, useEffect, useState, useMemo } from 'react';
import ReactFlow, {
  Node,
  Edge,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  ConnectionMode,
  Panel,
  NodeMouseHandler,
} from 'reactflow';
import 'reactflow/dist/style.css';
import dagre from 'dagre';
import { RefreshCw, Layers, Save, X } from 'lucide-react';
import { DeviceNode } from './nodes/DeviceNode';
import type { DeviceNodeData } from './nodes/DeviceNode';

interface ReactFlowTopologyViewerProps {
  viewName?: string;
  isVisible?: boolean;
  onViewChange?: (viewName: string) => void;
}

// 注册自定义节点类型
const nodeTypes = {
  device: DeviceNode,
};

/**
 * React Flow 版本的拓扑查看器
 *
 * 优势：
 * 1. React 原生集成，无生命周期问题
 * 2. 代码量减少 60%
 * 3. 无需手动管理 WebGL 实例
 * 4. Tab 切换时自动处理显示/隐藏
 */
export const ReactFlowTopologyViewer: React.FC<ReactFlowTopologyViewerProps> = ({
  viewName: propViewName = '',
  isVisible = true,
  onViewChange,
}) => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [loading, setLoading] = useState(true);
  const [hasChanges, setHasChanges] = useState(false);
  const [selectedNode, setSelectedNode] = useState<Node<DeviceNodeData> | null>(null);

  // 业务视图名称状态
  const [currentViewName, setCurrentViewName] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('dashboard-topology-view') || propViewName || '';
    }
    return propViewName || '';
  });
  const [isEditingViewName, setIsEditingViewName] = useState(false);
  const [editingViewNameValue, setEditingViewNameValue] = useState('');
  const [businessViews, setBusinessViews] = useState<Array<{ id: string; name: string; displayName?: string }>>([]);
  const [showViewSelector, setShowViewSelector] = useState(false);

  // 获取业务视图列表
  useEffect(() => {
    const fetchBusinessViews = async () => {
      try {
        const response = await fetch('/api/admin/business-views');
        if (response.ok) {
          const views = await response.json();
          setBusinessViews(views);

          // 如果没有选中的视图，默认选中第一个业务视图
          if (!currentViewName && views.length > 0) {
            const firstView = views[0].name;
            setCurrentViewName(firstView);
            if (typeof window !== 'undefined') {
              localStorage.setItem('dashboard-topology-view', firstView);
            }
            if (onViewChange) {
              onViewChange(firstView);
            }
          }
        }
      } catch (error) {
        console.error('Failed to fetch business views:', error);
      }
    };
    fetchBusinessViews();
  }, []);

  // Dagre 层次化布局算法
  const getLayoutedElements = useCallback((nodes: Node[], edges: Edge[]) => {
    const dagreGraph = new dagre.graphlib.Graph();
    dagreGraph.setDefaultEdgeLabel(() => ({}));
    dagreGraph.setGraph({
      rankdir: 'TB',      // 自上而下
      ranksep: 120,       // 层间距（缩小）
      nodesep: 80,        // 节点间距（缩小）
    });

    nodes.forEach((node) => {
      dagreGraph.setNode(node.id, { width: 160, height: 110 });
    });

    edges.forEach((edge) => {
      dagreGraph.setEdge(edge.source, edge.target);
    });

    dagre.layout(dagreGraph);

    const layoutedNodes = nodes.map((node) => {
      const nodeWithPosition = dagreGraph.node(node.id);
      return {
        ...node,
        position: {
          x: nodeWithPosition.x - 80,
          y: nodeWithPosition.y - 55,
        },
      };
    });

    return { nodes: layoutedNodes, edges };
  }, []);

  // 获取拓扑数据
  const fetchTopology = useCallback(async () => {
    if (!isVisible) return;

    // 如果没有选中业务视图，不加载数据
    const bvName = currentViewName || propViewName || '';
    if (!bvName) {
      setLoading(false);
      setNodes([]);
      setEdges([]);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/topology?bvName=${encodeURIComponent(bvName)}`);
      const data = await response.json();

      if (data.nodes && data.edges) {
        // 转换节点格式 - 完整保留 API 返回的数据
        const formattedNodes: Node<DeviceNodeData>[] = data.nodes.map((node: any) => ({
          id: node.id,
          type: 'device',
          position: node.position || { x: 0, y: 0 },
          data: {
            label: node.data.label || node.id,
            type: node.data.type || 'default',
            status: node.data.status || 'OFFLINE',
            ip: node.data.ip || '',
            icon: node.data.icon || '',
            cpu: node.data.cpu,
            memory: node.data.memory,
            metadata: node.data.metadata,
          },
        }));

        // 转换边格式 - 完整保留流量、状态等信息
        const formattedEdges: Edge[] = data.edges.map((edge: any) => ({
          id: edge.id,
          source: edge.source,
          target: edge.target,
          type: 'smoothstep',
          animated: edge.animated || false,
          label: edge.label || '',
          labelStyle: {
            fill: '#fff',
            fontSize: 11,
            fontWeight: 600,
          },
          labelBgStyle: {
            fill: '#1e293b',
            fillOpacity: 0.9,
          },
          labelBgPadding: [4, 6] as [number, number],
          labelBgBorderRadius: 4,
          style: {
            stroke: edge.style?.stroke || '#3b82f6',
            strokeWidth: edge.style?.strokeWidth || 2,
          },
          data: edge.data,
        }));

        // 如果节点没有位置信息，应用层次化布局
        const needsLayout = formattedNodes.every(
          (node) => node.position.x === 0 && node.position.y === 0
        );

        if (needsLayout && formattedNodes.length > 0) {
          const { nodes: layoutedNodes, edges: layoutedEdges } = getLayoutedElements(
            formattedNodes,
            formattedEdges
          );
          setNodes(layoutedNodes);
          setEdges(layoutedEdges);
        } else {
          setNodes(formattedNodes);
          setEdges(formattedEdges);
        }
      }
    } catch (error) {
      console.error('Failed to fetch topology:', error);
    } finally {
      setLoading(false);
    }
  }, [currentViewName, propViewName, isVisible, getLayoutedElements, setNodes, setEdges]);

  // 初始化和定时刷新
  useEffect(() => {
    if (isVisible) {
      fetchTopology();
      const interval = setInterval(fetchTopology, 30000);
      return () => clearInterval(interval);
    }
  }, [isVisible, fetchTopology]);

  // 加载 localStorage 中的视图名称
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedViewName = localStorage.getItem('dashboard-topology-view') || '';
      setCurrentViewName(savedViewName);
      if (onViewChange) {
        onViewChange(savedViewName);
      }
    }
  }, [onViewChange]);

  // 节点拖拽结束，标记为有变化
  const handleNodeDragStop = useCallback(() => {
    setHasChanges(true);
  }, []);

  // 节点点击事件
  const handleNodeClick: NodeMouseHandler = useCallback((event, node) => {
    setSelectedNode(node as Node<DeviceNodeData>);
  }, []);

  // 保存节点位置
  const saveNodePositions = useCallback(async () => {
    try {
      const response = await fetch('/api/topology/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          viewName: currentViewName,
          nodes: nodes.map(n => ({
            id: n.id,
            type: n.type,
            position: n.position,
            data: n.data,
          })),
          edges: edges.map(e => ({
            id: e.id,
            source: e.source,
            target: e.target,
            type: e.type,
            label: e.label,
            data: e.data,
          })),
        }),
      });

      if (response.ok) {
        setHasChanges(false);
        console.log('节点位置已保存');
      } else {
        const errorData = await response.json();
        console.error('保存失败:', errorData);
      }
    } catch (error) {
      console.error('保存节点位置失败:', error);
    }
  }, [nodes, edges, currentViewName]);

  // 自动保存（防抖 2 秒）
  useEffect(() => {
    if (hasChanges) {
      const timer = setTimeout(() => {
        saveNodePositions();
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [hasChanges, saveNodePositions]);

  // 业务视图编辑
  const handleEditViewName = () => {
    setEditingViewNameValue(currentViewName);
    setIsEditingViewName(true);
  };

  const handleSaveViewName = () => {
    const newViewName = editingViewNameValue.trim();
    setCurrentViewName(newViewName);
    if (typeof window !== 'undefined') {
      localStorage.setItem('dashboard-topology-view', newViewName);
    }
    if (onViewChange) {
      onViewChange(newViewName);
    }
    setIsEditingViewName(false);
    // 切换视图后重新获取数据
    setTimeout(() => fetchTopology(), 100);
  };

  const handleCancelEditViewName = () => {
    setIsEditingViewName(false);
    setEditingViewNameValue('');
  };

  const handleDeleteViewName = () => {
    setCurrentViewName('');
    if (typeof window !== 'undefined') {
      localStorage.removeItem('dashboard-topology-view');
    }
    if (onViewChange) {
      onViewChange('');
    }
    setIsEditingViewName(false);
    // 回到全局视图
    setTimeout(() => fetchTopology(), 100);
  };

  // 同步按钮
  const handleSync = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/topology/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ viewName: currentViewName }),
      });
      if (response.ok) {
        await fetchTopology();
      }
    } catch (error) {
      console.error('同步拓扑失败:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full h-full relative bg-[#0a1929]">
      {/* Loading 状态 */}
      {loading && nodes.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center z-50 bg-slate-950/50">
          <div className="flex flex-col items-center gap-4">
            <div className="w-8 h-8 border-4 border-cyan-500/30 border-t-cyan-500 rounded-full animate-spin" />
            <span className="text-xs font-mono text-cyan-500 uppercase tracking-widest">
              正在加载网络拓扑...
            </span>
          </div>
        </div>
      )}

      {/* 无业务视图提示 */}
      {!loading && !currentViewName && businessViews.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center z-50">
          <div className="flex flex-col items-center gap-4 text-center">
            <Layers className="w-16 h-16 text-cyan-500/50" />
            <div className="text-cyan-400 font-bold text-lg">未配置业务视图</div>
            <div className="text-slate-400 text-sm max-w-md">
              请前往 Admin 面板配置业务视图，业务视图将自动同步 OpManager 的 getBVDetails API 数据
            </div>
          </div>
        </div>
      )}

      {/* 请选择业务视图提示 */}
      {!loading && !currentViewName && businessViews.length > 0 && (
        <div className="absolute inset-0 flex items-center justify-center z-50">
          <div className="flex flex-col items-center gap-4 text-center">
            <Layers className="w-16 h-16 text-cyan-500/50" />
            <div className="text-cyan-400 font-bold text-lg">请选择业务视图</div>
            <div className="text-slate-400 text-sm max-w-md">
              点击顶部标题选择业务视图（来自 OpManager getBVDetails API）
            </div>
          </div>
        </div>
      )}

      {/* React Flow */}
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onNodeDragStop={handleNodeDragStop}
        onNodeClick={handleNodeClick}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: 0.2, maxZoom: 1.5 }}
        minZoom={0.1}
        maxZoom={4}
        connectionMode={ConnectionMode.Loose}
        defaultEdgeOptions={{
          type: 'smoothstep',
          animated: false,
          style: { strokeWidth: 2 },
        }}
      >
        {/* 背景网格 */}
        <Background color="#1e293b" gap={20} className="opacity-30" />

        {/* 控制按钮 */}
        <Controls className="bg-slate-900/80 border border-slate-700 rounded-lg" showInteractive={false} />

        {/* 小地图 - 移到左下角，使用深色背景避免遮挡 */}
        <MiniMap
          position="bottom-left"
          className="!bg-slate-950/90 border border-cyan-500/20 rounded-lg shadow-xl"
          style={{ width: 120, height: 80 }}
          nodeColor={(node) => {
            const status = node.data?.status;
            return status === 'ONLINE' ? '#22c55e' :
                   status === 'WARNING' ? '#eab308' :
                   status === 'ERROR' ? '#ef4444' :
                   '#6b7280';
          }}
          maskColor="rgba(10, 25, 41, 0.8)"
        />

        {/* 顶部标题栏 */}
        <Panel position="top-center" className="bg-slate-900/95 backdrop-blur-md border border-cyan-500/30 rounded-lg px-6 py-3">
          <div className="flex items-center gap-3">
            <Layers className="w-5 h-5 text-cyan-400" />

            {showViewSelector ? (
              <div className="flex items-center gap-2">
                <select
                  value={currentViewName}
                  onChange={(e) => {
                    const newViewName = e.target.value;
                    setCurrentViewName(newViewName);
                    if (typeof window !== 'undefined') {
                      localStorage.setItem('dashboard-topology-view', newViewName);
                    }
                    if (onViewChange) {
                      onViewChange(newViewName);
                    }
                    setShowViewSelector(false);
                    setTimeout(() => fetchTopology(), 100);
                  }}
                  className="px-3 py-1.5 bg-slate-800 text-white text-sm border border-cyan-500/50 rounded min-w-[200px]"
                  autoFocus
                >
                  {businessViews.length === 0 ? (
                    <option value="">请在 Admin 面板配置业务视图</option>
                  ) : (
                    businessViews.map((view) => (
                      <option key={view.id} value={view.name}>
                        {view.displayName || view.name}
                      </option>
                    ))
                  )}
                </select>
                <button
                  onClick={() => setShowViewSelector(false)}
                  className="p-1 bg-slate-700 text-white rounded hover:bg-slate-600 transition-colors"
                  title="取消"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <>
                <div
                  className="text-cyan-400 font-bold text-lg cursor-pointer hover:text-cyan-300 transition-colors"
                  onClick={() => setShowViewSelector(true)}
                  title="点击选择业务视图"
                >
                  {currentViewName ? (businessViews.find(v => v.name === currentViewName)?.displayName || currentViewName) : '请选择业务视图'}
                </div>
                <div className="text-slate-500 text-sm">
                  节点: {nodes.length} | 连接: {edges.length}
                </div>
              </>
            )}
          </div>
        </Panel>

        {/* 右上角操作按钮 */}
        <Panel position="top-right" className="flex gap-2">
          <button
            onClick={handleSync}
            disabled={loading}
            className="p-2 bg-slate-900/80 backdrop-blur-md border border-cyan-500/30 rounded-lg text-cyan-400 hover:text-cyan-300 transition-all shadow-xl active:scale-95 disabled:opacity-50"
            title="从 OpManager 同步拓扑"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          {hasChanges && (
            <button
              onClick={saveNodePositions}
              className="p-2 bg-cyan-500/80 backdrop-blur-md border border-cyan-400/30 rounded-lg text-white hover:bg-cyan-600 transition-all shadow-xl active:scale-95"
              title="保存节点位置"
            >
              <Save className="w-4 h-4" />
            </button>
          )}
        </Panel>
      </ReactFlow>

      {/* 节点详情面板 */}
      {selectedNode && (
        <div className="absolute right-4 top-4 bottom-4 w-72 bg-slate-950/90 backdrop-blur-md border border-cyan-500/30 rounded-lg shadow-2xl z-10 flex flex-col">
          {/* 关闭按钮 */}
          <button
            onClick={() => setSelectedNode(null)}
            className="absolute top-2 right-2 p-1 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* 详情内容 */}
          <div className="p-4 overflow-y-auto">
            <h3 className="text-lg font-bold text-cyan-400 mb-4">设备详情</h3>

            <div className="space-y-3 text-sm">
              <div>
                <div className="text-slate-500 mb-1">设备名称</div>
                <div className="text-white font-medium">{selectedNode.data.label}</div>
              </div>

              {selectedNode.data.ip && (
                <div>
                  <div className="text-slate-500 mb-1">IP 地址</div>
                  <div className="text-white font-mono">{selectedNode.data.ip}</div>
                </div>
              )}

              <div>
                <div className="text-slate-500 mb-1">设备类型</div>
                <div className="text-white">{selectedNode.data.type}</div>
              </div>

              <div>
                <div className="text-slate-500 mb-1">状态</div>
                <div className={`inline-flex items-center gap-2 px-2 py-1 rounded ${
                  selectedNode.data.status === 'ONLINE' ? 'bg-green-500/20 text-green-400' :
                  selectedNode.data.status === 'WARNING' ? 'bg-yellow-500/20 text-yellow-400' :
                  selectedNode.data.status === 'ERROR' ? 'bg-red-500/20 text-red-400' :
                  'bg-gray-500/20 text-gray-400'
                }`}>
                  <div className={`w-2 h-2 rounded-full ${
                    selectedNode.data.status === 'ONLINE' ? 'bg-green-500' :
                    selectedNode.data.status === 'WARNING' ? 'bg-yellow-500' :
                    selectedNode.data.status === 'ERROR' ? 'bg-red-500' :
                    'bg-gray-500'
                  }`} />
                  {selectedNode.data.status}
                </div>
              </div>

              {/* CPU 使用率 */}
              {selectedNode.data.cpu !== undefined && selectedNode.data.cpu !== null && (
                <div>
                  <div className="text-slate-500 mb-1">CPU 使用率</div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-slate-800 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-full transition-all ${
                          selectedNode.data.cpu > 80 ? 'bg-red-500' :
                          selectedNode.data.cpu > 60 ? 'bg-yellow-500' :
                          'bg-green-500'
                        }`}
                        style={{ width: `${Math.min(selectedNode.data.cpu, 100)}%` }}
                      />
                    </div>
                    <span className="text-white font-mono text-xs min-w-[45px]">
                      {selectedNode.data.cpu.toFixed(1)}%
                    </span>
                  </div>
                </div>
              )}

              {/* 内存使用率 */}
              {selectedNode.data.memory !== undefined && selectedNode.data.memory !== null && (
                <div>
                  <div className="text-slate-500 mb-1">内存使用率</div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-slate-800 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-full transition-all ${
                          selectedNode.data.memory > 80 ? 'bg-red-500' :
                          selectedNode.data.memory > 60 ? 'bg-yellow-500' :
                          'bg-green-500'
                        }`}
                        style={{ width: `${Math.min(selectedNode.data.memory, 100)}%` }}
                      />
                    </div>
                    <span className="text-white font-mono text-xs min-w-[45px]">
                      {selectedNode.data.memory.toFixed(1)}%
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReactFlowTopologyViewer;
