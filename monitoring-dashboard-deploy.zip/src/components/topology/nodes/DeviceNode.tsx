/**
 * 设备节点组件 - React Flow 自定义节点
 * 匹配截图中的视觉风格：深蓝色背景，青色边框，设备图标，中文标签
 */

import React from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { getDeviceIcon } from '../icons/DeviceIcons';

export interface DeviceNodeData {
  label: string;          // 设备名称（中文）
  type: string;           // 设备类型（firewall, switch, router, server, ac）
  status: 'ONLINE' | 'OFFLINE' | 'WARNING' | 'ERROR';
  ip?: string;            // IP 地址
  icon?: string;          // 图标 URL（可选，优先使用 SVG 图标）
  cpu?: number;           // CPU 使用率
  memory?: number;        // 内存使用率
  metadata?: any;         // 其他元数据
}

/**
 * 设备节点组件
 */
export const DeviceNode: React.FC<NodeProps<DeviceNodeData>> = ({ data, selected }) => {
  // 状态指示器颜色映射
  const statusColorMap = {
    ONLINE: 'bg-green-500',
    WARNING: 'bg-yellow-500',
    ERROR: 'bg-red-500',
    OFFLINE: 'bg-gray-500',
  };

  const statusColor = statusColorMap[data.status] || 'bg-gray-500';

  return (
    <div className="relative">
      {/* 顶部连接点 */}
      <Handle
        type="target"
        position={Position.Top}
        className="w-3 h-3 !bg-cyan-400 !border-2 !border-slate-900"
      />

      {/* 节点主体 */}
      <div
        className={`
          flex flex-col items-center gap-2
          px-4 py-3
          bg-[#1e3a8a]/80 backdrop-blur-md
          rounded-lg
          shadow-xl
          transition-all duration-200
          ${selected ? 'shadow-cyan-500/50 ring-2 ring-cyan-400' : ''}
        `}
        style={{
          minWidth: '140px',
          maxWidth: '160px',
        }}
      >
        {/* 设备图标 */}
        <div className="w-10 h-10 flex items-center justify-center">
          {getDeviceIcon(data.type, 'w-10 h-10')}
        </div>

        {/* 设备名称 */}
        <div className="text-white font-bold text-sm text-center leading-tight max-w-[200px] break-words">
          {data.label}
        </div>

        {/* IP 地址 */}
        {data.ip && (
          <div className="text-cyan-300 text-xs font-mono">
            {data.ip}
          </div>
        )}

        {/* 状态指示器 */}
        <div
          className={`
            absolute -top-2 -right-2
            w-4 h-4
            rounded-full
            ${statusColor}
            ${data.status === 'ONLINE' ? 'animate-pulse' : ''}
          `}
          title={data.status}
        />
      </div>

      {/* 底部连接点 */}
      <Handle
        type="source"
        position={Position.Bottom}
        className="w-3 h-3 !bg-cyan-400 !border-2 !border-slate-900"
      />
    </div>
  );
};

export default DeviceNode;
