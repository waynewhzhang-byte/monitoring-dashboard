import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

// Force dynamic rendering since this route uses request parameters
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const viewName = req.nextUrl.searchParams.get('bvName');

    // If no viewName (global view), fetch ALL topology data
    // Condition object for Prisma filter
    const whereClause = (viewName && viewName !== '') ? { viewName } : {};

    // 获取业务视图配置（包含相机状态）- Only if viewName exists
    const viewConfig = (viewName && viewName !== '')
      ? await prisma.businessViewConfig.findUnique({
        where: { name: viewName },
        select: {
          cameraX: true,
          cameraY: true,
          cameraZoom: true
        }
      })
      : null;

    const nodes = await prisma.topologyNode.findMany({
      where: whereClause,
      include: {
        device: {
          include: {
            metrics: {
              orderBy: { timestamp: 'desc' },
              take: 1
            }
          }
        }
      }
    });

    const edges = await prisma.topologyEdge.findMany({
      where: whereClause,
      include: {
        interface: {
          include: {
            trafficMetrics: {
              orderBy: { timestamp: 'desc' },
              take: 1
            }
          }
        }
      }
    });

    // Transform for ReactFlow; 节点状态：优先 node.device?.status，否则从 metadata 解析（与 OPM 一致）
    // OpManager 状态码: 1=严重 2=问题 3=注意 4=服务中断 5=正常 7=未管理
    const rfNodes = nodes.map(node => {
      const latestMetric = node.device?.metrics[0];
      const meta = (node.metadata as Record<string, unknown>) || {};
      const rawStatus = meta.status ?? meta.statusNum ?? (meta as Record<string, unknown>).Status;
      const metaStatus = String(rawStatus ?? '5').trim();
      const statusFromMeta =
        metaStatus === '5'
          ? 'ONLINE'
          : metaStatus === '1'
            ? 'ERROR'
            : metaStatus === '2' || metaStatus === '3'
              ? 'WARNING'
              : metaStatus === '4' || metaStatus === '7'
                ? 'OFFLINE'
                : metaStatus === '6'
                  ? 'UNMANAGED'
                  : undefined;
      const status = node.device?.status ?? statusFromMeta ?? 'ONLINE';
      return {
        id: node.id,
        type: 'customNode',
        position: { x: node.positionX, y: node.positionY },
        data: {
          label: node.label,
          type: node.type,
          icon: node.icon,
          status,
          deviceId: node.deviceId ?? undefined,
          ip: node.device?.ipAddress ?? (meta.ipAddress as string),
          cpu: latestMetric?.cpuUsage || 0,
          memory: latestMetric?.memoryUsage || 0,
          metadata: node.metadata
        }
      };
    });

    const rfEdges = edges.map(edge => {
      // Only fetch traffic metrics if interface is monitored
      const latestMetric = edge.interface?.isMonitored !== false
        ? edge.interface?.trafficMetrics[0]
        : null;
      const metadata = edge.metadata as any;

      // Use real-time traffic metric for label if available, otherwise fallback to metadata (含 destProps)
      const inTrafficRaw = metadata?.InTraffic ?? metadata?.destProps?.InTraffic;
      const outTrafficRaw = metadata?.OutTraffic ?? metadata?.destProps?.OutTraffic;
      const formatBw = (bps: number) => {
        if (bps >= 1000000000) return `${(bps / 1000000000).toFixed(1)}G`;
        if (bps >= 1000000) return `${(bps / 1000000).toFixed(1)}M`;
        if (bps >= 1000) return `${(bps / 1000).toFixed(1)}K`;
        return `${bps.toFixed(0)}`;
      };
      const norm = (s: string | undefined) =>
        s ? s.replace(/ bps/i, '').replace(/ Kbps/i, 'K').replace(/ Mbps/i, 'M').replace(/ Gbps/i, 'G').trim() : '0';

      let trafficLabel = '';
      if (latestMetric && latestMetric.inBandwidth != null) {
        const inBps = Number(latestMetric.inBandwidth);
        const outBps = Number(latestMetric.outBandwidth ?? 0);
        trafficLabel = `↓${formatBw(inBps)} ↑${formatBw(outBps)}`;
      } else if (inTrafficRaw || outTrafficRaw) {
        trafficLabel = `↓${norm(inTrafficRaw)} ↑${norm(outTrafficRaw)}`;
      } else if (metadata?.intfDisplayName || metadata?.ifName) {
        trafficLabel = metadata.intfDisplayName || metadata.ifName;
      } else if (edge.label) {
        trafficLabel = edge.label;
      } else {
        trafficLabel = '—';
      }

      // OPM 链接状态: 1/2 关闭/停止→红, 3 其他→黄, 4/7 取消管理→灰, 5 正常→绿
      const linkStatus = String((metadata?.status ?? '5'));
      const strokeColor =
        linkStatus === '1' || linkStatus === '2'
          ? '#ef4444'
          : linkStatus === '3'
            ? '#eab308'
            : linkStatus === '4' || linkStatus === '7'
              ? '#6b7280'
              : '#22c55e';

      return {
        id: edge.id,
        type: 'customEdge',
        source: edge.sourceId,
        target: edge.targetId,
        label: trafficLabel,
        animated: (latestMetric?.inUtilization || 0) > 70,
        style: {
          stroke: strokeColor,
          strokeWidth: 2
        },
        data: {
          status: linkStatus,
          inTraffic: trafficLabel,
          outTraffic: outTrafficRaw ?? metadata?.OutTraffic,
          utilization: latestMetric?.inUtilization,
          smoothType: metadata?.smoothType
        }
      };
    });

    return NextResponse.json({
      nodes: rfNodes,
      edges: rfEdges,
      camera: viewConfig ? {
        x: viewConfig.cameraX,
        y: viewConfig.cameraY,
        ratio: viewConfig.cameraZoom
      } : null
    });
  } catch (error) {
    console.error('Failed to fetch topology:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
