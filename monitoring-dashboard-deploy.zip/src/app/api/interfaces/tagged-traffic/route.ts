import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { opClient } from '@/services/opmanager/client';
import { DeviceStatus } from '@prisma/client';

/**
 * GET /api/interfaces/tagged-traffic?tag=<tagName>
 * Fetches real-time interface traffic from OpManager listInterfaces API
 * 
 * NOTE: This endpoint uses OpManager listInterfaces API for real-time data.
 * Topology traffic data should continue using database TrafficMetric (from topology sync).
 */
// Force dynamic rendering since this route uses request parameters
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const tag = req.nextUrl.searchParams.get('tag');

    if (!tag) {
      return NextResponse.json({ error: 'tag parameter is required' }, { status: 400 });
    }

    // Fetch interfaces with the specified tag from database
    // IMPORTANT: Include tags and opmanagerId in the query to verify tag matching
    const interfaces = await prisma.interface.findMany({
      where: {
        tags: {
          has: tag
        },
        isMonitored: true
      },
      select: {
        id: true,
        name: true,
        displayName: true,
        opmanagerId: true,
        tags: true,
        status: true,
        ifIndex: true,
        device: {
          select: {
            id: true,
            displayName: true,
            ipAddress: true,
            opmanagerId: true,
            name: true,
            status: true,
            isMonitored: true
          }
        }
      },
      orderBy: {
        displayName: 'asc'
      }
    });

    // Double-check: filter interfaces that actually have the tag
    // This ensures we only return interfaces with the specified tag
    const taggedInterfaces = interfaces.filter(iface => {
      const hasTag = iface.tags && Array.isArray(iface.tags) && iface.tags.includes(tag);
      if (!hasTag) {
        console.warn(`⚠️  Interface ${iface.id} (${iface.displayName || iface.name}) was returned by query but does not have tag "${tag}". Tags: ${JSON.stringify(iface.tags)}`);
      }
      return hasTag;
    });

    console.log(`🔍 Tagged interface traffic query: tag="${tag}", found ${taggedInterfaces.length} interfaces (after filtering from ${interfaces.length} total)`);
    
    // Log all found interfaces for debugging
    if (taggedInterfaces.length > 0) {
      console.log(`📋 Interfaces with tag "${tag}":`);
      taggedInterfaces.forEach(iface => {
        console.log(`  - ${iface.displayName || iface.name} (opmanagerId: ${iface.opmanagerId}, tags: ${JSON.stringify(iface.tags)})`);
      });
    } else {
      console.log(`⚠️  No monitored interfaces found with tag "${tag}"`);
      // Also check if there are interfaces with isMonitored=false that have this tag
      const allTaggedInterfaces = await prisma.interface.findMany({
        where: {
          tags: {
            has: tag
          }
        },
        select: {
          id: true,
          name: true,
          displayName: true,
          opmanagerId: true,
          tags: true,
          isMonitored: true
        }
      });
      if (allTaggedInterfaces.length > 0) {
        const monitoredCount = allTaggedInterfaces.filter(i => i.isMonitored).length;
        const unmonitoredCount = allTaggedInterfaces.length - monitoredCount;
        console.log(`⚠️  Found ${allTaggedInterfaces.length} total interfaces with tag "${tag}": ${monitoredCount} monitored, ${unmonitoredCount} unmonitored`);
        if (unmonitoredCount > 0) {
          console.log(`⚠️  Unmonitored interfaces with tag "${tag}" (will not be displayed):`);
          allTaggedInterfaces.filter(i => !i.isMonitored).forEach(iface => {
            console.log(`  - ${iface.displayName || iface.name} (opmanagerId: ${iface.opmanagerId}, tags: ${JSON.stringify(iface.tags)})`);
          });
        }
      }
    }

    if (taggedInterfaces.length === 0) {
      return NextResponse.json({ interfaces: [] });
    }

    // Group interfaces by device IP address to minimize API calls
    // Only include devices that have at least one monitored interface
    // getInterfaces API requires device IP address, not deviceName/opmanagerId
    const interfacesByDeviceIp = new Map<string, {
      ipAddress: string;
      deviceName: string;
      interfaces: typeof interfaces;
    }>();
    taggedInterfaces.forEach(iface => {
      // Only process monitored interfaces (already filtered by isMonitored: true in query)
      // Also skip devices that are OFFLINE/UNMANAGED to avoid meaningless OpManager calls
      // NOTE: WARNING/ERROR 不是离线，属于“在线但有故障/告警”，仍应允许拉取实时流量/接口数据
      if (
        iface.device.isMonitored !== true ||
        iface.device.status === DeviceStatus.OFFLINE ||
        iface.device.status === DeviceStatus.UNMANAGED
      ) {
        console.warn(
          `⚠️  Skipping device ${iface.device.displayName || iface.device.name} (${iface.device.ipAddress}): ` +
          `status=${iface.device.status}, isMonitored=${iface.device.isMonitored}`
        );
        return;
      }

      const deviceIp = iface.device.ipAddress;
      if (!deviceIp) {
        console.warn(`⚠️  Skipping interface ${iface.id}: device IP address is missing`);
        return;
      }
      
      if (!interfacesByDeviceIp.has(deviceIp)) {
        interfacesByDeviceIp.set(deviceIp, {
          ipAddress: deviceIp,
          deviceName: iface.device.displayName || iface.device.name,
          interfaces: []
        });
      }
      interfacesByDeviceIp.get(deviceIp)!.interfaces.push(iface);
    });

    // Skip devices with no monitored interfaces (shouldn't happen due to query filter, but double-check)
    if (interfacesByDeviceIp.size === 0) {
      return NextResponse.json({ interfaces: [] });
    }

    // Fetch real-time traffic data from OpManager for each device
    const interfaceTraffic: Array<{
      id: string;
      name: string;
      deviceName: string;
      deviceIp: string;
      inBandwidth: string;
      outBandwidth: string;
      inBandwidthRaw: number;
      outBandwidthRaw: number;
      inUtilization: number;
      outUtilization: number;
      status: string;
      timestamp: Date;
    }> = [];

    for (const [deviceIp, deviceData] of interfacesByDeviceIp.entries()) {
      try {
        // Fetch interfaces from OpManager getInterfaces API
        // API requires device IP address (e.g., "1.1.1.45"), not deviceName/opmanagerId
        const opInterfaces = await opClient.getInterfaces({
          deviceIpAddress: deviceIp
        });

        // Create a map of OpManager interfaces by name/displayName
        // Also try to match by ifIndex if available
        const opInterfaceMap = new Map<string, any>();
        const opInterfaceMapByIfIndex = new Map<number, any>();
        opInterfaces.forEach(opIface => {
          // Map by both name and displayName for matching
          const key1 = opIface.name || '';
          const key2 = opIface.displayName || '';
          if (key1) opInterfaceMap.set(key1.toLowerCase(), opIface);
          if (key2) opInterfaceMap.set(key2.toLowerCase(), opIface);
          
          // Also map by ifIndex if available (for more reliable matching)
          if (opIface.ifIndex !== undefined && opIface.ifIndex !== null) {
            opInterfaceMapByIfIndex.set(opIface.ifIndex, opIface);
          }
        });
        
        console.log(`📡 Fetched ${opInterfaces.length} interfaces from OpManager for device ${deviceIp}`);
        console.log(`   OpManager interface names: ${opInterfaces.map(i => i.name || i.displayName).join(', ')}`);

        // Match database interfaces with OpManager interfaces
        // IMPORTANT: Only process interfaces that have the specified tag
        for (const dbInterface of deviceData.interfaces) {
          // Double-check: ensure this interface has the specified tag
          if (!dbInterface.tags || !Array.isArray(dbInterface.tags) || !dbInterface.tags.includes(tag)) {
            console.warn(`⚠️  Skipping interface ${dbInterface.id} (${dbInterface.displayName || dbInterface.name}, opmanagerId: ${dbInterface.opmanagerId}): does not have tag "${tag}". Tags: ${JSON.stringify(dbInterface.tags)}`);
            continue;
          }

          const interfaceName = dbInterface.displayName || dbInterface.name;
          console.log(`🔍 Matching interface: ${interfaceName} (opmanagerId: ${dbInterface.opmanagerId})`);
          
          // IMPORTANT: Database interface name format is now "设备名称+接口名称" (e.g., "服务器20_195-Ethernet65-IF-10.141.50.114.100")
          // But OpManager returns original interface name (e.g., "Ethernet65-IF-10.141.50.114.100")
          // We need to extract the original interface name from the database name for matching
          const extractOriginalInterfaceName = (dbName: string): string => {
            // If name contains "-", try to extract the interface part after the device name
            // Format: "设备名称-接口名称" -> extract "接口名称"
            const parts = dbName.split('-');
            if (parts.length > 1) {
              // Try to find the interface part (usually contains "IF-" or interface type like "Ethernet", "Loopback", etc.)
              // Skip the first part (device name) and join the rest
              for (let i = 1; i < parts.length; i++) {
                const candidate = parts.slice(i).join('-');
                // Check if this looks like an interface name (contains "IF-" or interface type)
                if (candidate.includes('IF-') || /^(Ethernet|Loopback|VLAN|IEEE|Gigabit|FastEthernet)/i.test(candidate)) {
                  return candidate;
                }
              }
              // If no clear pattern, return everything after first "-"
              return parts.slice(1).join('-');
            }
            return dbName;
          };
          
          const originalInterfaceName = extractOriginalInterfaceName(dbInterface.name);
          const originalDisplayName = dbInterface.displayName ? extractOriginalInterfaceName(dbInterface.displayName) : null;
          
          console.log(`   Database name: "${dbInterface.name}", extracted original: "${originalInterfaceName}"`);
          if (originalDisplayName) {
            console.log(`   Database displayName: "${dbInterface.displayName}", extracted original: "${originalDisplayName}"`);
          }
          
          // Try multiple matching strategies:
          // 1. Match by extracted original interface name from database name
          // 2. Match by extracted original interface name from displayName
          // 3. Match by original database name/displayName (fallback)
          // 4. Match by ifIndex if available (most reliable)
          let opInterface = opInterfaceMap.get(originalInterfaceName.toLowerCase()) ||
                           (originalDisplayName ? opInterfaceMap.get(originalDisplayName.toLowerCase()) : null) ||
                           opInterfaceMap.get(interfaceName.toLowerCase()) ||
                           opInterfaceMap.get(dbInterface.name.toLowerCase());
          
          // If name matching failed, try ifIndex matching (if we have ifIndex in database)
          if (!opInterface && dbInterface.ifIndex !== null && dbInterface.ifIndex !== undefined) {
            opInterface = opInterfaceMapByIfIndex.get(dbInterface.ifIndex);
            if (opInterface) {
              console.log(`✅ Matched interface ${interfaceName} by ifIndex ${dbInterface.ifIndex}`);
            }
          }
          
          if (!opInterface) {
            console.warn(`⚠️  Interface ${interfaceName} (opmanagerId: ${dbInterface.opmanagerId}, ifIndex: ${dbInterface.ifIndex}) not found in OpManager response.`);
            console.warn(`   Database interface name: "${dbInterface.name}", displayName: "${dbInterface.displayName}"`);
            console.warn(`   Available OpManager interfaces: ${opInterfaces.map(i => `"${i.name || i.displayName}" (ifIndex: ${i.ifIndex || i.ifIndexNum || 'N/A'})`).join(', ')}`);
          } else {
            console.log(`✅ Matched interface ${interfaceName} with OpManager interface "${opInterface.name || opInterface.displayName}"`);
          }

          if (opInterface) {
            // Parse traffic strings (e.g., "3.768 K", "1.144 M", "10 G", "69.148 M (0.0%)", "NA")
            // Format: "69.148 M (0.0%)" - traffic value and utilization in parentheses
            // Handle "NA" values (return 0)
            const parseTraffic = (trafficStr: string): number => {
              if (!trafficStr || trafficStr.trim() === '' || trafficStr.trim().toUpperCase() === 'NA' || trafficStr === '0' || trafficStr === '0 bps') return 0;
              
              // Remove utilization part in parentheses if present (e.g., "69.148 M (0.0%)" -> "69.148 M")
              const trafficOnly = trafficStr.trim().replace(/\s*\([^)]*\)\s*$/, '').trim();
              
              const parts = trafficOnly.split(/\s+/);
              if (parts.length < 2) return 0;
              
              const value = parseFloat(parts[0]);
              if (isNaN(value)) return 0;
              
              const unit = parts[1].toUpperCase();
              
              // Convert to bps (bits per second)
              let multiplier = 1;
              if (unit === 'K' || unit === 'KB' || unit === 'KBPS') {
                multiplier = 1000;
              } else if (unit === 'M' || unit === 'MB' || unit === 'MBPS') {
                multiplier = 1000 * 1000;
              } else if (unit === 'G' || unit === 'GB' || unit === 'GBPS') {
                multiplier = 1000 * 1000 * 1000;
              } else if (unit === 'T' || unit === 'TB' || unit === 'TBPS') {
                multiplier = 1000 * 1000 * 1000 * 1000;
              } else if (unit === 'BPS') {
                multiplier = 1;
              }
              
              return value * multiplier;
            };

            // Parse utilization from traffic string or separate field
            // Format: "69.148 M (0.0%)" - extract percentage from parentheses
            const parseUtilizationFromTraffic = (trafficStr: string): number => {
              if (!trafficStr) return 0;
              
              // Extract percentage from parentheses (e.g., "69.148 M (0.0%)" -> 0.0)
              const match = trafficStr.match(/\(([\d.]+)%\)/);
              if (match && match[1]) {
                const value = parseFloat(match[1]);
                return isNaN(value) ? 0 : value;
              }
              
              return 0;
            };

            // Parse utilization from separate field or traffic string
            // Handle "NA" values (return 0)
            const parseUtilization = (utilStr: string | undefined, trafficStr?: string): number => {
              // First try to get from separate field
              if (utilStr && utilStr.trim().toUpperCase() !== 'NA') {
                const value = parseFloat(utilStr);
                if (!isNaN(value)) return value;
              }
              
              // Fallback: extract from traffic string parentheses
              if (trafficStr) {
                return parseUtilizationFromTraffic(trafficStr);
              }
              
              return 0;
            };

            const inTrafficStr = opInterface.inTraffic || '0';
            const outTrafficStr = opInterface.outTraffic || '0';
            
            const inBandwidthRaw = parseTraffic(inTrafficStr);
            const outBandwidthRaw = parseTraffic(outTrafficStr);
            
            // Try multiple field names for utilization, or extract from traffic string
            const inUtilization = parseUtilization(
              opInterface.inUtil || 
              opInterface.inUtilization || 
              (opInterface as any).inUtilPercent,
              inTrafficStr  // Pass traffic string as fallback
            );
            const outUtilization = parseUtilization(
              opInterface.outUtil || 
              opInterface.outUtilization || 
              (opInterface as any).outUtilPercent,
              outTrafficStr  // Pass traffic string as fallback
            );

            // Format bandwidth to readable string (Mbps/Gbps)
            const formatBandwidth = (bytes: number): string => {
              const mbps = bytes / (1000 * 1000);
              if (mbps >= 1000) {
                return `${(mbps / 1000).toFixed(1)} G`;
              }
              return `${mbps.toFixed(1)} M`;
            };

            // Determine status from OpManager data
            let status = dbInterface.status;
            if (opInterface.statusStr) {
              // Map OpManager status to our InterfaceStatus enum
              const statusMap: Record<string, 'UP' | 'DOWN' | 'TESTING' | 'DORMANT' | 'UNKNOWN'> = {
                '正常': 'UP',
                'Clear': 'UP',
                '问题': 'DOWN',
                'Trouble': 'DOWN',
                '严重': 'DOWN',
                'Critical': 'DOWN',
                '停止': 'DOWN',
                'Down': 'DOWN'
              };
              status = (statusMap[opInterface.statusStr] as 'UP' | 'DOWN' | 'TESTING' | 'DORMANT' | 'UNKNOWN') || dbInterface.status;
            }

            interfaceTraffic.push({
              id: dbInterface.id,
              name: dbInterface.displayName || dbInterface.name,
              deviceName: deviceData.deviceName,
              deviceIp: deviceData.ipAddress,
              inBandwidth: formatBandwidth(inBandwidthRaw),
              outBandwidth: formatBandwidth(outBandwidthRaw),
              inBandwidthRaw: inBandwidthRaw,
              outBandwidthRaw: outBandwidthRaw,
              inUtilization: inUtilization,
              outUtilization: outUtilization,
              status: status,
              timestamp: new Date()
            });
          } else {
            // If interface not found in OpManager, use database status but no traffic data
            interfaceTraffic.push({
              id: dbInterface.id,
              name: dbInterface.displayName || dbInterface.name,
              deviceName: deviceData.deviceName,
              deviceIp: deviceData.ipAddress,
              inBandwidth: '0 M',
              outBandwidth: '0 M',
              inBandwidthRaw: 0,
              outBandwidthRaw: 0,
              inUtilization: 0,
              outUtilization: 0,
              status: dbInterface.status,
              timestamp: new Date()
            });
          }
        }
      } catch (error) {
        console.error(`Failed to fetch interfaces for device IP ${deviceIp}:`, error);
        // Continue with other devices even if one fails
      }
    }

    return NextResponse.json({ interfaces: interfaceTraffic });
  } catch (error) {
    console.error('Failed to fetch tagged interface traffic:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
