import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { opClient } from '@/services/opmanager/client';
import { DeviceStatus } from '@prisma/client';

/**
 * GET /api/interfaces/realtime-traffic?tag=<tagName>
 * Fetches real-time interface traffic data from OpManager listInterfaces API
 * This is used for dashboard widgets, NOT for topology display
 */
// Force dynamic rendering since this route uses request parameters
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    // Use req.nextUrl.searchParams instead of new URL(req.url) to avoid static generation issues
    const tag = req.nextUrl.searchParams.get('tag');

    // Support special "__all__" tag to fetch all monitored interfaces
    const fetchAllInterfaces = tag === '__all__' || tag === null || tag === '';

    if (!fetchAllInterfaces && !tag) {
      return NextResponse.json({ error: 'tag parameter is required' }, { status: 400 });
    }

    // Fetch interfaces with the specified tag from database, or all monitored interfaces if tag is __all__
    const whereClause = fetchAllInterfaces
      ? { isMonitored: true } // Fetch all monitored interfaces
      : {
          tags: { has: tag },
          isMonitored: true
        };
    
    const interfaces = await prisma.interface.findMany({
      where: whereClause,
      include: {
        device: {
          select: {
            id: true,
            displayName: true,
            ipAddress: true,
            opmanagerId: true,
            name: true,
            status: true,
            isMonitored: true
          }
        }
      },
      orderBy: {
        displayName: 'asc'
      }
    });

    if (interfaces.length === 0) {
      return NextResponse.json({ interfaces: [] });
    }

    // Group interfaces by device IP address to minimize API calls
    // getInterfaces API requires device IP address, not deviceName/opmanagerId
    const interfacesByDeviceIp = new Map<string, {
      ipAddress: string;
      deviceName: string;
      interfaces: typeof interfaces;
    }>();
    interfaces.forEach(iface => {
      // Skip devices that are OFFLINE/UNMANAGED to avoid meaningless OpManager calls
      // NOTE: WARNING/ERROR 不是离线，属于“在线但有故障/告警”，仍应允许拉取实时流量/接口数据
      if (
        iface.device.isMonitored !== true ||
        iface.device.status === DeviceStatus.OFFLINE ||
        iface.device.status === DeviceStatus.UNMANAGED
      ) {
        console.warn(
          `⚠️  Skipping device ${iface.device.displayName || iface.device.name} (${iface.device.ipAddress}): ` +
          `status=${iface.device.status}, isMonitored=${iface.device.isMonitored}`
        );
        return;
      }

      const deviceIp = iface.device.ipAddress;
      if (!deviceIp) {
        console.warn(`⚠️  Skipping interface ${iface.id}: device IP address is missing`);
        return;
      }
      
      if (!interfacesByDeviceIp.has(deviceIp)) {
        interfacesByDeviceIp.set(deviceIp, {
          ipAddress: deviceIp,
          deviceName: iface.device.displayName || iface.device.name,
          interfaces: []
        });
      }
      interfacesByDeviceIp.get(deviceIp)!.interfaces.push(iface);
    });

    // Fetch real-time traffic data from OpManager for each device
    const interfaceTraffic: Array<{
      id: string;
      name: string;
      deviceName: string;
      deviceIp: string;
      inBandwidth: string;
      outBandwidth: string;
      inBandwidthRaw: number;
      outBandwidthRaw: number;
      inUtilization: number;
      outUtilization: number;
      status: string;
      timestamp: Date;
    }> = [];

    for (const [deviceIp, deviceData] of interfacesByDeviceIp.entries()) {
      try {
        // Fetch interfaces from OpManager getInterfaces API
        // API requires device IP address (e.g., "1.1.1.45"), not deviceName/opmanagerId
        const opInterfaces = await opClient.getInterfaces({
          deviceIpAddress: deviceIp
        });

        // Create a map of OpManager interfaces by name/displayName
        const opInterfaceMap = new Map<string, any>();
        opInterfaces.forEach(opIface => {
          // Map by both name and displayName for matching
          const key1 = opIface.name || '';
          const key2 = opIface.displayName || '';
          if (key1) opInterfaceMap.set(key1.toLowerCase(), opIface);
          if (key2) opInterfaceMap.set(key2.toLowerCase(), opIface);
        });

        // Match database interfaces with OpManager interfaces
        for (const dbInterface of deviceData.interfaces) {
          const interfaceName = dbInterface.displayName || dbInterface.name;
          const opInterface = opInterfaceMap.get(interfaceName.toLowerCase()) ||
                             opInterfaceMap.get(dbInterface.name.toLowerCase());

          if (opInterface) {
            // Parse traffic strings (e.g., "3.768 K", "1.144 M", "10 G", "69.148 M (0.0%)")
            // Format: "69.148 M (0.0%)" - traffic value and utilization in parentheses
            const parseTraffic = (trafficStr: string): number => {
              if (!trafficStr || trafficStr.trim() === '' || trafficStr === '0' || trafficStr === '0 bps') return 0;
              
              // Remove utilization part in parentheses if present (e.g., "69.148 M (0.0%)" -> "69.148 M")
              const trafficOnly = trafficStr.trim().replace(/\s*\([^)]*\)\s*$/, '').trim();
              
              const parts = trafficOnly.split(/\s+/);
              if (parts.length < 2) return 0;
              
              const value = parseFloat(parts[0]);
              if (isNaN(value)) return 0;
              
              const unit = parts[1].toUpperCase();
              
              // Convert to bps (bits per second)
              let multiplier = 1;
              if (unit === 'K' || unit === 'KB' || unit === 'KBPS') {
                multiplier = 1000;
              } else if (unit === 'M' || unit === 'MB' || unit === 'MBPS') {
                multiplier = 1000 * 1000;
              } else if (unit === 'G' || unit === 'GB' || unit === 'GBPS') {
                multiplier = 1000 * 1000 * 1000;
              } else if (unit === 'T' || unit === 'TB' || unit === 'TBPS') {
                multiplier = 1000 * 1000 * 1000 * 1000;
              } else if (unit === 'BPS') {
                multiplier = 1;
              }
              
              return value * multiplier;
            };

            // Parse utilization from traffic string or separate field
            // Format: "69.148 M (0.0%)" - extract percentage from parentheses
            const parseUtilizationFromTraffic = (trafficStr: string): number => {
              if (!trafficStr) return 0;
              
              // Extract percentage from parentheses (e.g., "69.148 M (0.0%)" -> 0.0)
              const match = trafficStr.match(/\(([\d.]+)%\)/);
              if (match && match[1]) {
                const value = parseFloat(match[1]);
                return isNaN(value) ? 0 : value;
              }
              
              return 0;
            };

            // Parse utilization from separate field or traffic string
            // Handle "NA" values (return 0)
            const parseUtilization = (utilStr: string | undefined, trafficStr?: string): number => {
              // First try to get from separate field
              if (utilStr && utilStr.trim().toUpperCase() !== 'NA') {
                const value = parseFloat(utilStr);
                if (!isNaN(value)) return value;
              }
              
              // Fallback: extract from traffic string parentheses
              if (trafficStr) {
                return parseUtilizationFromTraffic(trafficStr);
              }
              
              return 0;
            };

            const inTrafficStr = opInterface.inTraffic || '0';
            const outTrafficStr = opInterface.outTraffic || '0';
            
            const inBandwidthRaw = parseTraffic(inTrafficStr);
            const outBandwidthRaw = parseTraffic(outTrafficStr);
            
            // Try multiple field names for utilization, or extract from traffic string
            const inUtilization = parseUtilization(
              opInterface.inUtil || 
              opInterface.inUtilization || 
              (opInterface as any).inUtilPercent,
              inTrafficStr  // Pass traffic string as fallback
            );
            const outUtilization = parseUtilization(
              opInterface.outUtil || 
              opInterface.outUtilization || 
              (opInterface as any).outUtilPercent,
              outTrafficStr  // Pass traffic string as fallback
            );

            // Format bandwidth to readable string (Mbps/Gbps)
            const formatBandwidth = (bytes: number): string => {
              const mbps = bytes / (1000 * 1000);
              if (mbps >= 1000) {
                return `${(mbps / 1000).toFixed(1)} G`;
              }
              return `${mbps.toFixed(1)} M`;
            };

            // Determine status from OpManager data
            let status = dbInterface.status;
            if (opInterface.statusStr) {
              // Map OpManager status to our InterfaceStatus enum
              const statusMap: Record<string, 'UP' | 'DOWN' | 'TESTING' | 'DORMANT' | 'UNKNOWN'> = {
                '正常': 'UP',
                'Clear': 'UP',
                '问题': 'DOWN',
                'Trouble': 'DOWN',
                '严重': 'DOWN',
                'Critical': 'DOWN',
                '停止': 'DOWN',
                'Down': 'DOWN'
              };
              status = (statusMap[opInterface.statusStr] as 'UP' | 'DOWN' | 'TESTING' | 'DORMANT' | 'UNKNOWN') || dbInterface.status;
            }

            interfaceTraffic.push({
              id: dbInterface.id,
              name: dbInterface.displayName || dbInterface.name,
              deviceName: deviceData.deviceName,
              deviceIp: deviceData.ipAddress,
              inBandwidth: formatBandwidth(inBandwidthRaw),
              outBandwidth: formatBandwidth(outBandwidthRaw),
              inBandwidthRaw: inBandwidthRaw,
              outBandwidthRaw: outBandwidthRaw,
              inUtilization: inUtilization,
              outUtilization: outUtilization,
              status: status,
              timestamp: new Date()
            });
          } else {
            // If interface not found in OpManager, use database status but no traffic data
            interfaceTraffic.push({
              id: dbInterface.id,
              name: dbInterface.displayName || dbInterface.name,
              deviceName: deviceData.deviceName,
              deviceIp: deviceData.ipAddress,
              inBandwidth: '0 M',
              outBandwidth: '0 M',
              inBandwidthRaw: 0,
              outBandwidthRaw: 0,
              inUtilization: 0,
              outUtilization: 0,
              status: dbInterface.status,
              timestamp: new Date()
            });
          }
        }
      } catch (error) {
        console.error(`Failed to fetch interfaces for device IP ${deviceIp}:`, error);
        // Continue with other devices even if one fails
      }
    }

    return NextResponse.json({ interfaces: interfaceTraffic });
  } catch (error) {
    console.error('Failed to fetch real-time interface traffic:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
