/**
 * PM2 进程管理配置文件
 * 用于 Ubuntu / 银河麒麟等 Linux 生产环境管理监控系统服务
 * 
 * 使用方法：
 *   pm2 start ecosystem.config.js          # 启动所有服务
 *   pm2 start ecosystem.config.js --only monitoring-web      # 只启动 Web 服务
 *   pm2 start ecosystem.config.js --only monitoring-collector # 只启动采集服务
 *   pm2 stop all                           # 停止所有服务
 *   pm2 restart all                        # 重启所有服务
 *   pm2 logs                               # 查看所有日志
 *   pm2 monit                              # 监控面板
 */

module.exports = {
  apps: [
    {
      name: 'monitoring-web',
      script: 'npm',
      args: 'start',
      cwd: '/opt/monitoring-app',  // 项目根目录（根据实际部署路径修改）
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      error_file: './logs/pm2-web-error.log',
      out_file: './logs/pm2-web-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s',
      watch: false,  // 生产环境关闭文件监听
      max_memory_restart: '1G',
    },
    {
      name: 'monitoring-collector',
      script: 'npm',
      args: 'run collector',
      cwd: '/opt/monitoring-app',  // 项目根目录（根据实际部署路径修改）
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        USE_MOCK_DATA: 'false',  // 生产环境使用真实 OpManager API
        // 采集/同步周期（秒）——按需调整
        COLLECT_METRICS_INTERVAL: '60',   // 指标采集周期
        COLLECT_ALARMS_INTERVAL: '30',    // 告警同步周期
        SYNC_TOPOLOGY_INTERVAL: '300',    // 业务视图/拓扑同步周期（默认 5 分钟）
      },
      error_file: './logs/pm2-collector-error.log',
      out_file: './logs/pm2-collector-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s',
      watch: false,  // 生产环境关闭文件监听
      max_memory_restart: '512M',
    },
  ],
};
