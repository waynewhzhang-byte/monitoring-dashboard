# 监控大屏项目部署指南（目标环境: Ubuntu）

## 打包信息
- 打包时间: 2026-01-30 12:47:26
- 项目: monitoring-dashboard（大屏 + Collector）
- 目标环境: Ubuntu（推荐 20.04 / 22.04 LTS）
- 已排除: node_modules、.next、dist、logs、.git

## 服务说明
- **monitoring-web**: Next.js 大屏前端（默认端口 3000）
- **monitoring-collector**: 数据采集服务（OpManager 设备/告警/拓扑同步）

## Ubuntu 前置依赖（首次部署前执行）

在运行一键部署脚本前，建议在 Ubuntu 上安装：

`ash
# Node.js 18+（推荐 NodeSource）
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 解压工具
sudo apt-get install -y unzip

# 若使用本地数据库与 Redis（可选，也可使用远程）
sudo apt-get install -y postgresql redis-server
`

若使用远程 PostgreSQL/Redis，只需在 .env 中配置 DATABASE_URL、REDIS_URL 即可。

## 快速部署（推荐）

### 1. 传输到服务器
`ash
scp monitoring-dashboard-deploy.zip user@server:/home/user/
`

### 2. 解压并一键部署
解压后根目录含有 deploy-monitoring-dashboard.sh，执行即可。
`ash
unzip monitoring-dashboard-deploy.zip -d /opt/monitoring-app
cd /opt/monitoring-app
chmod +x deploy-monitoring-dashboard.sh
./deploy-monitoring-dashboard.sh
`

### 3. 环境变量
部署前请准备 .env（可复制 .env.example 后修改）：
- DATABASE_URL: PostgreSQL 连接
- REDIS_URL: Redis 连接（可选）
- OpManager: OPMANAGER_BASE_URL、OPMANAGER_USER、OPMANAGER_PASSWORD 等

## 端口与 PM2
- Web 大屏: 3000
- PM2 管理: pm2 status | pm2 logs | pm2 restart all

## Ubuntu 防火墙（如需对外开放 3000）
`ash
sudo ufw allow 3000/tcp
sudo ufw reload
`
