#!/bin/bash
set -e

# 颜色
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo "========================================"
echo "  Dashboard 部署脚本"
echo "========================================"

# 1. 检查环境
if ! command -v node &> /dev/null; then
    echo -e "${RED}Error: Node.js 未安装${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Node.js $(node -v)${NC}"

# 2. 安装依赖
echo "----------------------------------------"
echo "正在安装依赖..."
# 优先清除缓存，防止平台不兼容问题
npm cache clean --force

# 删除旧的 node_modules (如果存在)
rm -rf node_modules

# 使用 npm install 而不是 ci，以确保重新计算依赖树适应当前平台
# 并确保安装 devDependencies (包含 prisma CLI)
npm install

# 显式安装 tsx 和 prisma (防止 package.json 定义有误)
npm install tsx prisma --save-dev

echo -e "${GREEN}✓ 依赖安装完成${NC}"

# 3. 数据库初始化
echo "----------------------------------------"
echo "正在初始化数据库..."

# 检查 prisma 文件
if [ ! -f "prisma/schema.prisma" ]; then
    echo -e "${RED}Error: prisma/schema.prisma 不存在!${NC}"
    exit 1
fi

# 生成客户端 (使用 npx 确保调用的是本地安装的 prisma)
echo "执行: npx prisma generate"
npx prisma generate

echo -e "${GREEN}✓ Prisma Client 生成成功${NC}"

# 可选：推送结构
# echo "正在同步数据库结构..."
# npm run db:push

# 4. 构建
echo "----------------------------------------"
echo "正在构建应用..."
npm run build
echo -e "${GREEN}✓ 构建成功${NC}"

# 5. 提示启动
echo "----------------------------------------"
echo "部署准备完成。请使用 PM2 启动:"
echo "pm2 start ecosystem.config.js"
echo "或手动启动:"
echo "npm run start"
