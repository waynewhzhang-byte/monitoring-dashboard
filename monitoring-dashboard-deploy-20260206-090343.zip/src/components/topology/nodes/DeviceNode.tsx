/**
 * 设备节点组件 - 简约监控大屏风格
 * 优化: 更简洁的设计，突出状态和核心信息
 */

import React from 'react';
import { Handle, Position, NodeProps } from 'reactflow';
import { getDeviceIcon } from '../icons/DeviceIcons';

export interface DeviceNodeData {
  label: string;          // 设备名称
  type: string;           // 设备类型
  status: 'ONLINE' | 'OFFLINE' | 'WARNING' | 'ERROR';
  ip?: string;            // IP 地址
  icon?: string;          // 图标 URL
  cpu?: number;           // CPU 使用率
  memory?: number;        // 内存使用率
  metadata?: any;         // 其他元数据
}

/**
 * 设备节点组件 - 简约风格
 */
export const DeviceNode: React.FC<NodeProps<DeviceNodeData>> = ({ data, selected }) => {
  // 根据设备状态获取颜色方案
  const getDeviceColors = (deviceStatus: string) => {
    // 告警状态
    if (deviceStatus === 'ERROR') {
      return {
        bg: 'bg-red-500/10',
        border: 'border-red-500/50',
        icon: 'text-red-400',
        ring: 'ring-red-500/50',
        glow: 'shadow-[0_0_15px_rgba(239,68,68,0.3)]',
        dot: 'bg-red-500',
      };
    }

    if (deviceStatus === 'WARNING') {
      return {
        bg: 'bg-yellow-500/10',
        border: 'border-yellow-500/50',
        icon: 'text-yellow-400',
        ring: 'ring-yellow-500/50',
        glow: 'shadow-[0_0_15px_rgba(234,179,8,0.3)]',
        dot: 'bg-yellow-500',
      };
    }

    if (deviceStatus === 'OFFLINE' || deviceStatus === 'UNMANAGED') {
      return {
        bg: 'bg-gray-500/10',
        border: 'border-gray-500/30',
        icon: 'text-gray-400',
        ring: 'ring-gray-500/30',
        glow: '',
        dot: 'bg-gray-500',
      };
    }

    // 正常状态 - 蓝色
    return {
      bg: 'bg-blue-500/10',
      border: 'border-blue-500/30',
      icon: 'text-blue-400',
      ring: 'ring-blue-500/50',
      glow: 'shadow-[0_0_12px_rgba(59,130,246,0.2)]',
      dot: 'bg-blue-500',
    };
  };

  const colors = getDeviceColors(data.status);

  return (
    <div className="relative">
      {/* 顶部连接点 - 隐藏 */}
      <Handle
        type="target"
        position={Position.Top}
        className="w-1 h-1 !bg-transparent !border-0 opacity-0"
      />

      {/* 节点主体 - 极简风格 */}
      <div
        className={`
          flex flex-col items-center gap-2
          transition-all duration-200
          ${selected ? 'scale-110' : ''}
        `}
        style={{
          maxWidth: '90px',
        }}
      >
        {/* 图标容器 - 简洁圆形设计 */}
        <div
          className={`
            relative
            w-14 h-14
            flex items-center justify-center
            ${colors.bg}
            rounded-full
            border-2 ${colors.border}
            transition-all duration-200
            ${selected ? `ring-2 ${colors.ring} ${colors.glow}` : colors.glow}
            backdrop-blur-sm
          `}
        >
          {/* 设备图标 */}
          <div className="w-7 h-7 flex items-center justify-center">
            {getDeviceIcon(data.type, `w-7 h-7 ${colors.icon}`)}
          </div>

          {/* 状态指示器 - 右上角小点 */}
          <div
            className={`
              absolute -top-0.5 -right-0.5
              w-3 h-3
              rounded-full
              border-2 border-[#0a0e1a]
              ${colors.dot}
              ${data.status === 'ERROR' || data.status === 'WARNING' ? 'animate-pulse' : ''}
            `}
            title={data.status}
          />
        </div>

        {/* 设备名称 */}
        <div className="w-full text-center px-1">
          <div className="text-white text-[10px] font-medium leading-tight break-words line-clamp-2">
            {data.label}
          </div>

          {/* IP 地址 - 可选显示 */}
          {data.ip && (
            <div className="text-slate-500 text-[8px] font-mono mt-1 truncate">
              {data.ip}
            </div>
          )}
        </div>
      </div>

      {/* 底部连接点 - 隐藏 */}
      <Handle
        type="source"
        position={Position.Bottom}
        className="w-1 h-1 !bg-transparent !border-0 opacity-0"
      />
    </div>
  );
};

export default DeviceNode;
