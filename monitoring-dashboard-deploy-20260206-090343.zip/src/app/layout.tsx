import type { Metadata } from 'next'
import './globals.css'

// 使用系统字体，避免依赖 Google Fonts（生产环境可能无法访问外网）
// 如果需要使用 Inter 字体，可以配置本地字体文件或使用代理

export const metadata: Metadata = {
  title: '智能监控大屏系统',
  description: '企业级网络监控可视化平台',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="zh-CN">
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
