/*
  Warnings:

  - Added the required column `viewName` to the `TopologyEdge` table without a default value. This is not possible if the table is not empty.
  - Added the required column `viewName` to the `TopologyNode` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "BusinessViewConfig" ADD COLUMN     "cameraX" DOUBLE PRECISION,
ADD COLUMN     "cameraY" DOUBLE PRECISION,
ADD COLUMN     "cameraZoom" DOUBLE PRECISION;

-- AlterTable
ALTER TABLE "Device" ADD COLUMN     "group" TEXT,
ADD COLUMN     "tags" TEXT[] DEFAULT ARRAY[]::TEXT[];

-- AlterTable
ALTER TABLE "Interface" ADD COLUMN     "tags" TEXT[] DEFAULT ARRAY[]::TEXT[];

-- AlterTable
ALTER TABLE "TopologyEdge" ADD COLUMN     "viewName" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "TopologyNode" ADD COLUMN     "viewName" TEXT NOT NULL;

-- CreateIndex
CREATE INDEX "Device_group_idx" ON "Device"("group");

-- CreateIndex
CREATE INDEX "Device_tags_idx" ON "Device"("tags");

-- CreateIndex
CREATE INDEX "Interface_tags_idx" ON "Interface"("tags");

-- CreateIndex
CREATE INDEX "TopologyEdge_viewName_idx" ON "TopologyEdge"("viewName");

-- CreateIndex
CREATE INDEX "TopologyNode_viewName_idx" ON "TopologyNode"("viewName");
