-- CreateTable (if not exists)
CREATE TABLE IF NOT EXISTS "BusinessViewConfig" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "displayName" TEXT,
    "description" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "refreshInterval" INTEGER NOT NULL DEFAULT 300,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BusinessViewConfig_pkey" PRIMARY KEY ("id")
);

-- CreateIndex (if not exists)
CREATE UNIQUE INDEX IF NOT EXISTS "BusinessViewConfig_name_key" ON "BusinessViewConfig"("name");

-- CreateTable
CREATE TABLE "DeviceBusinessView" (
    "id" TEXT NOT NULL,
    "deviceId" TEXT NOT NULL,
    "viewName" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "DeviceBusinessView_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "DeviceBusinessView_deviceId_viewName_key" ON "DeviceBusinessView"("deviceId", "viewName");

-- CreateIndex
CREATE INDEX "DeviceBusinessView_deviceId_idx" ON "DeviceBusinessView"("deviceId");

-- CreateIndex
CREATE INDEX "DeviceBusinessView_viewName_idx" ON "DeviceBusinessView"("viewName");

-- AddForeignKey
ALTER TABLE "DeviceBusinessView" ADD CONSTRAINT "DeviceBusinessView_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES "Device"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DeviceBusinessView" ADD CONSTRAINT "DeviceBusinessView_viewName_fkey" FOREIGN KEY ("viewName") REFERENCES "BusinessViewConfig"("name") ON DELETE CASCADE ON UPDATE CASCADE;
