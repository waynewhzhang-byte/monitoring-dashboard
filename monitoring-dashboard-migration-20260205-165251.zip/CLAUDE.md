# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

---

# Monitoring Dashboard - 开发指南

企业级网络设备监控大屏系统，集成 ManageEngine OpManager API 进行实时设备监控、告警管理和网络拓扑可视化。

## 技术栈

- **前端**: Next.js 14 (Pages Router + App Router), React 18, TypeScript
- **UI**: Tailwind CSS, shadcn/ui, Framer Motion
- **状态管理**: Zustand
- **数据库**: PostgreSQL + Prisma ORM
- **缓存**: Redis (ioredis)
- **实时通信**: Socket.io + WebSocket
- **图表**: Recharts
- **拓扑可视化**: Sigma.js, React Flow, react-grid-layout
- **数据采集**: node-cron + OpManager REST API

## 常用命令

### 开发和构建
```bash
npm run dev              # 启动开发服务器 (http://localhost:3000)
npm run build            # 生产构建
npm run start            # 启动生产服务器
npm run lint             # 代码检查
npm run type-check       # TypeScript 类型检查
```

### 数据库操作
```bash
npm run db:generate      # 生成 Prisma Client
npm run db:push          # 同步 schema 到数据库 (不创建迁移)
npm run db:migrate       # 创建并应用迁移
npm run db:seed          # 填充种子数据
npm run db:studio        # 打开 Prisma Studio GUI
npm run db:reset         # 重置数据库 (危险!)
```

### 数据采集器
```bash
npm run collector        # 启动生产数据采集器 (连接真实 OpManager)
npm run mock-collector   # 启动 Mock 采集器 (测试用)
```

### 诊断和验证工具
```bash
# ⭐ 大屏显示诊断（推荐）
npm run diagnose:display      # 【重要】大屏无数据时运行此命令
                              # 检查: 环境→OpManager→数据库→BV→API→采集器

# 核心诊断
npm run diagnose:dashboard    # 诊断仪表板 API
npm run diagnose:database     # 诊断数据库数据
npm run diagnose:all          # 运行所有本地诊断

# 生产环境诊断
npm run diagnose:production   # 完整生产环境诊断
npm run diagnose:opmanager    # 验证 OpManager 实际数据
npm run diagnose:api-calls    # 诊断 API 调用

# 数据检查工具
npm run check:sync            # 检查设备同步状态
npm run check:interfaces      # 检查接口数量
npm run check:alarms          # 检查告警同步
npm run check:tags            # 检查设备标签
npm run check:all             # 运行所有检查

# 验证工具
npm run verify:production     # 验证生产同步
npm run verify:opmanager-apis # 验证所有 OpManager API
npm run verify:data-flow      # 【重要】验证完整数据流（OpManager→数据库→API）
```

### 测试
```bash
npm run test             # 运行单元测试
npm run test:watch       # 监视模式运行测试
npm run test:coverage    # 生成测试覆盖率报告
```

### 代码格式化
```bash
npm run format           # 格式化代码
npm run format:check     # 检查代码格式
```

## 核心架构

### 数据流

```
OpManager API → Collectors → PostgreSQL/Redis → Next.js API Routes → WebSocket → 前端组件
     ↓              ↓              ↓                   ↓                ↓
  REST API    node-cron      Prisma ORM        Socket.io       Zustand Store
```

### 关键设计决策

1. **混合路由模式**
   - Pages Router: 现有功能 (`/pages/*`, `/pages/api/*`)
   - App Router: 新功能如 admin 面板 (`/app/admin/*`)

2. **实时通信**: Socket.io WebSocket (非 SSE)
   - 服务端: Socket.io Server
   - 客户端: Socket.io Client
   - Redis Adapter: 支持多实例扩展

3. **数据采集策略**
   - **自动定时采集**:
     - Metrics: 每 60 秒
     - Alarms: 每 30 秒
     - Topology: 每 5 分钟
   - **手动触发**:
     - Devices: 通过 `/api/devices/sync` 或 admin 面板按钮
     - Interfaces: 通过 `/api/interfaces/sync` 或 admin 面板按钮
   - **原因**: 设备和接口变化不频繁，手动同步可减少 API 压力

4. **缓存策略**
   - Redis 缓存热点数据 (设备列表、拓扑数据)
   - TTL: 60 秒
   - 写入时主动失效缓存

## 目录结构重点

```
src/
├── app/                      # App Router (新功能)
│   ├── api/                 # App Router API 路由
│   ├── admin/               # 管理面板
│   └── dashboard/           # 新版仪表板
├── pages/                    # Pages Router (现有)
│   ├── api/                 # Pages API 路由 (主要 API)
│   ├── dashboards/          # 仪表板页面
│   └── topology/            # 拓扑编辑器
├── components/
│   ├── dashboard/           # 仪表板组件
│   ├── dashboard-builder/   # 仪表板构建器 (可拖拽布局)
│   ├── domain/              # 领域组件 (设备、告警、拓扑)
│   ├── topology/            # 拓扑可视化组件
│   ├── widgets/             # 可复用小部件
│   └── ui/                  # shadcn/ui 基础组件
├── services/
│   ├── collector/           # 数据采集服务 (start.ts 入口)
│   │   ├── device.ts       # 设备采集 (手动)
│   │   ├── interface.ts    # 接口采集 (手动)
│   │   ├── metric.ts       # 指标采集 (自动)
│   │   ├── alarm.ts        # 告警采集 (自动)
│   │   └── topology.ts     # 拓扑采集 (自动)
│   ├── opmanager/           # OpManager API 客户端
│   │   ├── client.ts       # HTTP 客户端
│   │   ├── data-collector.ts
│   │   └── data-mapper.ts  # API 响应映射
│   ├── alarm/               # 告警去重和处理
│   └── broadcast/           # WebSocket 广播服务
├── lib/
│   ├── prisma.ts            # Prisma Client 单例
│   ├── redis.ts             # Redis Client 单例
│   ├── logger.ts            # Winston 日志
│   └── utils.ts             # 通用工具函数
├── types/
│   ├── index.ts             # 通用类型
│   ├── opmanager.ts         # OpManager API 类型
│   └── dashboard-config.ts  # 仪表板配置类型
├── stores/
│   └── useDashboardStore.ts # Zustand 仪表板状态
└── hooks/
    └── useWidgetData.ts     # Widget 数据 Hook

prisma/
└── schema.prisma            # 数据库 Schema

scripts/                      # 诊断和工具脚本 (见上方命令)
```

## 核心概念

### 1. OpManager API 集成

```typescript
// src/services/opmanager/client.ts
// 封装所有 OpManager REST API 调用
// 主要 API:
// - listDevices: 获取设备列表
// - getDeviceDetails: 获取设备详情
// - listInterfaces: 获取接口列表
// - getAlarms: 获取告警
// - getBusinessViews: 获取业务视图
```

**重要**: OpManager API 响应结构不一致，需要在 `data-mapper.ts` 中进行标准化映射。

### 2. 数据模型 (Prisma)

核心模型:
- `Device`: 设备 (路由器、交换机、服务器等)
- `Interface`: 网络接口
- `DeviceMetric`: 设备性能指标 (CPU、内存、磁盘)
- `TrafficMetric`: 接口流量指标
- `Alarm`: 告警记录
- `TopologyNode` & `TopologyEdge`: 拓扑图节点和边
- `BusinessViewConfig`: 业务视图配置

**关键字段**:
- `opmanagerId`: OpManager 原始 ID (用于关联)
- `isMonitored`: 是否监控 (设备/接口)
- `tags`: 设备标签 (String[])

### 3. 告警去重

```typescript
// src/services/alarm/deduplicator.ts
// 基于以下维度去重:
// - deviceId + message + severity
// - 时间窗口: 5 分钟
```

### 4. 仪表板构建器

使用 `react-grid-layout` 实现可拖拽仪表板:
- 编辑模式: 可拖动、调整大小
- 查看模式: 只读
- 配置存储在 `src/config/dashboards/*.ts`

### 5. 拓扑可视化

两种实现:
- **Sigma.js**: 大规模网络拓扑 (1000+ 节点)
- **React Flow**: 小型拓扑编辑器 (可拖拽)

## 开发规范

### API 路由规范

```typescript
// ✅ RESTful 风格
GET    /api/devices              // 设备列表
GET    /api/devices/:id          // 设备详情
GET    /api/devices/:id/interfaces // 设备接口
POST   /api/devices/sync         // 手动同步设备

GET    /api/alarms               // 告警列表
POST   /api/alarms/:id/acknowledge

GET    /api/topology/save        // 拓扑保存
```

### OpManager API 调用

```typescript
// ✅ 统一错误处理
try {
  const devices = await opManagerClient.listDevices();
  // 映射到内部模型
  const mapped = devices.map(mapOpManagerDeviceToModel);
  // 批量写入
  await prisma.device.createMany({ data: mapped, skipDuplicates: true });
} catch (error) {
  logger.error('OpManager API failed', { error });
  // 不要中断整个采集流程
}
```

### 数据库查询优化

```typescript
// ✅ 选择必要字段
const devices = await prisma.device.findMany({
  select: { id: true, name: true, status: true },
  where: { isMonitored: true },
});

// ✅ 使用 include 避免 N+1
const devicesWithInterfaces = await prisma.device.findMany({
  include: {
    interfaces: { where: { isMonitored: true } }
  },
});

// ✅ 分页查询
const devices = await prisma.device.findMany({
  skip: (page - 1) * pageSize,
  take: pageSize,
});
```

### 组件设计

```typescript
// ✅ 容器组件处理数据
export function DeviceListContainer() {
  const { devices, loading } = useDashboardStore();
  useEffect(() => { fetchDevices(); }, []);

  if (loading) return <LoadingSpinner />;
  return <DeviceList devices={devices} />;
}

// ✅ 展示组件纯展示
export function DeviceList({ devices }: { devices: Device[] }) {
  return (
    <div className="grid gap-4">
      {devices.map(device => <DeviceCard key={device.id} device={device} />)}
    </div>
  );
}
```

## 环境变量

必需配置 (`.env`):

```bash
# 数据库
DATABASE_URL="postgresql://user:password@localhost:5432/monitoring_dashboard"

# Redis
REDIS_URL="redis://localhost:6379"

# OpManager API
OPMANAGER_BASE_URL="https://opmanager.example.com:8061"
OPMANAGER_API_KEY="your-api-key"
OPMANAGER_TIMEOUT=30000

# 应用
NODE_ENV="production"
NEXT_PUBLIC_WS_URL="http://localhost:3000"
PORT=3000
```

参考 `.env.production.example` 获取完整配置。

## 常见任务

### 添加新的 Widget 类型

1. 在 `src/types/dashboard-config.ts` 定义类型
2. 在 `src/components/widgets/` 创建组件
3. 在 `src/components/dashboard-builder/WidgetRenderer.tsx` 注册
4. 在 `src/hooks/useWidgetData.ts` 添加数据获取逻辑

### 添加新的 Collector

1. 在 `src/services/collector/` 创建 `xxx.ts`
2. 实现 `Collector` 接口 (可选)
3. 在 `start.ts` 中添加 cron 调度
4. 考虑是否需要缓存清理

### 调试 OpManager API

```bash
# 1. 验证所有 API 端点
npm run verify:opmanager-apis

# 2. 检查实际数据
npm run diagnose:opmanager

# 3. 诊断 API 调用
npm run diagnose:api-calls
```

### 测试生产环境

```bash
# 【推荐】完整数据流验证（一键验证采集→数据库→API）
npm run verify:data-flow

# 完整诊断流程
npm run diagnose:production

# 验证同步状态
npm run verify:production

# 检查所有数据
npm run check:all
```

**`verify:data-flow` 说明**:
- 全面验证 OpManager API → 采集器 → 数据库 → Dashboard API 的完整链路
- 测试所有采集器（设备、接口、指标、告警）
- 检查数据一致性和时效性
- 生成详细测试报告和性能统计
- 适合部署后验证和定期健康检查
- 详见: [scripts/VERIFY-DATA-FLOW-README.md](scripts/VERIFY-DATA-FLOW-README.md)

## 性能注意事项

1. **OpManager API**
   - 超时时间: 30 秒
   - 避免频繁调用 (使用缓存)
   - 批量请求时考虑限流

2. **数据库查询**
   - 始终使用 `select` 选择字段
   - 大列表必须分页
   - 为常用查询添加索引 (见 `schema.prisma`)

3. **Redis 缓存**
   - 缓存键命名: `prefix:entity:id`
   - TTL: 60 秒 (可调整)
   - 写入时主动失效

4. **WebSocket**
   - 避免发送大数据
   - 使用 房间 (rooms) 隔离不同客户端
   - 心跳检测避免僵尸连接

## 故障排查

### 采集器不工作

```bash
# 1. 检查环境变量
npm run test:env

# 2. 验证 OpManager 连接
npm run verify:opmanager-apis

# 3. 查看采集器日志
# (如果使用 PM2: pm2 logs collector)
```

### 数据不更新

```bash
# 1. 检查同步状态
npm run check:sync

# 2. 手动触发同步
# 访问 admin 面板点击同步按钮
# 或调用 POST /api/devices/sync

# 3. 检查数据库数据
npm run db:studio
```

### 仪表板显示异常

```bash
# 1. 诊断仪表板数据
npm run diagnose:dashboard

# 2. 检查浏览器控制台
# F12 → Console 查看错误

# 3. 验证 WebSocket 连接
# F12 → Network → WS 查看连接状态
```

## 测试

```bash
# 运行所有测试
npm run test

# 监视模式 (自动重跑)
npm run test:watch

# 测试覆盖率
npm run test:coverage
```

测试文件位于 `src/**/__tests__/` 目录。

## 部署

### 本地开发

```bash
# 1. 安装依赖
npm install

# 2. 配置环境变量
cp .env.production.example .env
# 编辑 .env 填入实际配置

# 3. 启动数据库 (Docker)
docker-compose up -d postgres redis

# 4. 初始化数据库
npm run db:push
npm run db:seed

# 5. 启动开发服务器
npm run dev

# 6. 启动采集器 (新终端)
npm run collector
```

### 生产部署

```bash
# 构建
npm run build

# 启动应用
npm run start

# 启动采集器 (独立进程)
npm run collector
```

推荐使用 PM2 管理进程:

```bash
pm2 start ecosystem.config.js
pm2 logs
pm2 status
```

## 文档

### 核心文档
- [README.md](./README.md) - 项目简介和快速开始
- [CLAUDE.md](./CLAUDE.md) - 本文档，开发指南
- [prisma/schema.prisma](./prisma/schema.prisma) - 数据库 Schema

### 配置和部署指南 ⭐
- **[COMPLETE-SETUP-GUIDE.md](./COMPLETE-SETUP-GUIDE.md)** - 📘 完整配置指南（必读）
  - 从 OpManager 到大屏的完整数据流
  - Admin 面板配置详解
  - Business View 配置步骤
  - 常见问题排查

- **[QUICK-START-CHECKLIST.md](./QUICK-START-CHECKLIST.md)** - ⚡ 快速启动清单
  - 15-30 分钟快速上线
  - 分步检查清单
  - 时间线参考
  - 故障快速排查

### 诊断和验证工具
- [scripts/VERIFY-DATA-FLOW-README.md](./scripts/VERIFY-DATA-FLOW-README.md) - 数据流验证脚本详细说明
- [scripts/QUICK-VERIFY-GUIDE.md](./scripts/QUICK-VERIFY-GUIDE.md) - 快速验证指南
- [scripts/README.md](./scripts/README.md) - 所有诊断脚本说明

---

**版本**: 2.0.0
**最后更新**: 2026-01-24
**维护者**: Wayne Zhang
