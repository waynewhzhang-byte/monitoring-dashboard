# 监控大屏系统 Ubuntu 迁移部署指南

## 打包信息
- 打包时间: 2026-02-05 16:52:55
- 打包环境: Windows
- 目标环境: Ubuntu (已有 Node.js、PM2、PostgreSQL、Redis)
- 打包类型: 完整迁移（源代码 + 配置文件 + 部署脚本）
- 安全说明:
  * ✓ 所有环境变量文件已自动清理敏感信息
  * ✓ 不包含 node_modules、.next 等构建产物
  * ✓ 在目标环境重新构建，确保兼容性

## 文件清单
- 已包含: 所有源代码、配置文件、环境变量文件
- 已排除: node_modules、.next、dist、logs、git历史
- 环境变量文件: 3 个
- 修复工具: scripts/fix-ubuntu-prisma-deps.sh

## 迁移步骤

### 1. 传输文件到Ubuntu服务器

`ash
# 使用SCP传输（从Windows）
scp monitoring-dashboard-migration-20260205-165251.zip username@server-ip:/home/username/

# 或使用FTP/SFTP工具上传
`

### 2. 解压部署包

`ash
# SSH登录到Ubuntu服务器
ssh username@server-ip

# 创建部署目录
sudo mkdir -p /var/www/exmam-register
cd /var/www/exmam-register

# 解压文件
unzip ~/monitoring-dashboard-migration-20260205-165251.zip

# 设置权限
sudo chown -R $USER:$USER /var/www/exmam-register
`

### 3. 运行一键部署脚本（推荐）

`ash
# 赋予执行权限
chmod +x deploy-ubuntu.sh

# 执行部署脚本（自动完成依赖安装、构建、启动）
./deploy-ubuntu.sh
`

**或者手动安装依赖：**

`ash
# 主应用依赖（完整安装，包含构建工具）
npm ci

# H5子应用依赖
cd h5-display-app && npm ci && cd ..
cd h5-proctor-app && npm ci && cd ..
cd h5-wework-app && npm ci && cd ..
`

**注意**: 必须使用 \
pm ci\ 而不是 \
pm install --only=production\，因为需要 devDependencies 中的 prisma CLI 来生成 Prisma 客户端。详见 \UBUNTU_404_QUICK_FIX.md\

### 4. 检查环境变量

所有环境变量文件已包含在部署包中。请检查并根据Ubuntu环境调整：

`ash
# 检查主应用环境变量
cat .env

# 主要需要修改的配置：
# - DATABASE_URL: 确认PostgreSQL连接字符串
# - APP_SECRET: 保持与Windows一致（如需修改，用户需重新登录）
# - CORS_ALLOWED_ORIGINS: 更新为Ubuntu服务器IP/域名
`

#### 主应用 .env 配置检查项

`ash
# 必须配置项
DATABASE_URL="postgresql://user:password@localhost:5432/exmam_register"
APP_SECRET="your-secret-key"

# 可选配置项
WEWORK_CORP_ID="ww..."
WEWORK_AGENT_ID="1000001"
WEWORK_AGENT_SECRET="..."
CORS_ALLOWED_ORIGINS="http://your-server-ip:5173,http://your-server-ip:3002"
`

#### H5应用环境变量检查

`ash
# h5-display-app/.env.production
VITE_API_BASE_URL=http://your-server-ip:3000

# h5-proctor-app/.env.production
VITE_API_BASE_URL=http://your-server-ip:3000

# h5-wework-app/.env.production
VITE_API_BASE_URL=http://your-server-ip:3000
`

### 5. 数据库迁移（如需要）

如果需要迁移数据库数据：

`ash
# 方法1: 从Windows导出数据库（在Windows上执行）
pg_dump -U postgres -h localhost exmam_register > exmam_register_backup.sql

# 传输到Ubuntu
scp exmam_register_backup.sql username@server-ip:/home/username/

# 在Ubuntu上导入（需先创建数据库）
psql -U postgres -c "CREATE DATABASE exmam_register;"
psql -U postgres -d exmam_register < exmam_register_backup.sql
`

如果是新数据库：

`ash
# 生成Prisma Client
npm run prisma:generate

# 推送schema到数据库
npm run prisma:push

# 初始化种子数据
npm run seed
npm run seed:exam-structure
`

### 6. 构建应用

`ash
# 主应用构建
npm run build

# H5应用构建
cd h5-display-app && npm run build && cd ..
cd h5-proctor-app && npm run build && cd ..
cd h5-wework-app && npm run build && cd ..
`

### 7. 启动应用（使用PM2）

`ash
# 安装PM2（如未安装）
sudo npm install -g pm2

# 创建日志目录
mkdir -p logs

# 启动所有应用
pm2 start ecosystem.config.js

# 查看状态
pm2 status

# 查看日志
pm2 logs

# 保存PM2配置（开机自启）
pm2 save
pm2 startup
# 执行命令输出的sudo命令
`

### 8. 验证部署

检查各个服务是否正常运行：

`ash
# 检查主应用
curl http://localhost:3000/api/health

# 检查H5应用
curl http://localhost:3002
curl http://localhost:5173
curl http://localhost:5174
`

浏览器访问：
- 主应用（管理后台）: http://server-ip:3000
- 显示屏H5: http://server-ip:3002
- 企业微信H5: http://server-ip:5173
- 监考H5: http://server-ip:5174

## PM2管理命令速查

`ash
# 查看所有应用状态
pm2 status

# 查看日志
pm2 logs                      # 所有应用
pm2 logs exmam-register       # 主应用
pm2 logs h5-display-app       # 显示屏应用

# 重启应用
pm2 restart all               # 重启所有
pm2 restart exmam-register    # 重启主应用

# 停止应用
pm2 stop all

# 删除应用
pm2 delete all
`

## 端口配置

默认端口：
- 主应用: 3000
- h5-display-app: 3002
- h5-wework-app: 5173
- h5-proctor-app: 5174

修改端口：编辑 ecosystem.config.js 和各H5应用的 package.json

## 防火墙配置

`ash
# Ubuntu防火墙开放端口
sudo ufw allow 3000/tcp
sudo ufw allow 3002/tcp
sudo ufw allow 5173/tcp
sudo ufw allow 5174/tcp
sudo ufw reload
`

## 常见问题

### 问题1: 数据库连接失败
检查 .env 中的 DATABASE_URL 是否正确，PostgreSQL是否运行：
`ash
sudo systemctl status postgresql
`

### 问题2: 端口被占用
检查端口占用：
`ash
sudo netstat -tulpn | grep :3000
`

### 问题3: 权限问题
确保用户对部署目录有完整权限：
`ash
sudo chown -R $USER:$USER /var/www/exmam-register
`

### 问题4: 环境变量未生效
PM2需要重新加载环境变量：
`ash
pm2 restart all --update-env
`

### 问题5: Prisma 依赖安装失败 (重要)

**症状**: 
- 运行 \
pm run prisma:generate\ 时出现错误
- 错误信息包含 "Cannot find module" 或 "c12/dist/index.mjs"
- Prisma Client 生成失败

**原因**:
- Prisma 版本不匹配（@prisma/client 和 prisma CLI 版本不同）
- npm 缓存问题导致模块解析失败
- package-lock.json 跨平台兼容性问题

**解决方案1: 使用独立修复脚本（推荐）**

项目已包含专门的修复脚本：

`ash
# 赋予执行权限
chmod +x scripts/fix-ubuntu-prisma-deps.sh

# 运行修复脚本
./scripts/fix-ubuntu-prisma-deps.sh
`

此脚本会自动：
- 诊断当前依赖状态
- 清理 node_modules 和 package-lock.json
- 清理 npm 缓存
- 重新安装所有依赖
- 生成 Prisma Client
- 验证安装结果

**解决方案2: 手动修复**

`ash
# 1. 清理现有安装
rm -rf node_modules package-lock.json

# 2. 清理 npm 缓存
npm cache clean --force

# 3. 重新安装依赖
npm install

# 4. 生成 Prisma Client
npm run prisma:generate

# 5. 验证安装
node -e "const { PrismaClient } = require('@prisma/client'); console.log('成功');"
`

**解决方案3: 检查版本一致性**

确保 package.json 中 Prisma 版本一致：

`ash
# 查看当前版本
npm list @prisma/client prisma

# 应该显示相同版本（例如都是 6.19.1）
# 如果版本不同，更新 package.json 后重新安装
`

## 安全建议

1. **修改默认密码**: 部署后立即修改管理员密码
2. **配置HTTPS**: 生产环境使用Nginx反向代理+SSL证书
3. **定期备份**: 设置数据库自动备份
4. **监控日志**: 定期检查PM2日志，监控异常

## 支持文档

- **快速修复**: UBUNTU_404_QUICK_FIX.md（Prisma 依赖错误解决方案）
- **优化部署**: deploy-ubuntu-optimized.sh（构建后清理开发依赖）
- 数据库迁移: MIGRATION.md
- PM2配置说明: PM2_DEPLOYMENT_GUIDE.md
- 项目说明: CLAUDE.md

---
生成时间: 2026-02-05 16:52:55
