#!/bin/bash
# ============================================
# Ubuntu一键部署脚本 (增强版)
# ============================================
# 修复说明:
# - 添加 npm cache 清理以解决模块解析问题
# - 添加依赖安装失败时的回退机制
# - 增强 Prisma 依赖验证
# ============================================

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 日志函数
log_step() {
    echo -e "\n${CYAN}[步骤] $1${NC}"
}

log_success() {
    echo -e "  ${GREEN}✓ $1${NC}"
}

log_error() {
    echo -e "  ${RED}✗ $1${NC}"
}

log_warning() {
    echo -e "  ${YELLOW}⚠ $1${NC}"
}

log_info() {
    echo -e "  $1"
}

# 显示标题
echo ""
echo "========================================"
echo "  exmam-register 一键部署脚本 (增强版)"
echo "========================================"
echo ""

# 检查是否在项目根目录
if [ ! -f "package.json" ]; then
    log_error "错误: 请在项目根目录执行此脚本"
    exit 1
fi

log_success "项目根目录验证通过"

# 检查必需工具
log_step "检查系统环境"

# 检查Node.js
if ! command -v node &> /dev/null; then
    log_error "Node.js 未安装"
    log_info "请安装 Node.js 18+ : curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt-get install -y nodejs"
    exit 1
fi
log_success "Node.js: $(node -v)"

# 检查Node.js版本
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    log_error "Node.js 版本过低，需要 18+，当前版本: $(node -v)"
    exit 1
fi

# 检查npm
if ! command -v npm &> /dev/null; then
    log_error "npm 未安装"
    exit 1
fi
log_success "npm: $(npm -v)"

# 检查PostgreSQL
if ! command -v psql &> /dev/null; then
    log_warning "PostgreSQL 未检测到（如果使用远程数据库可忽略）"
else
    log_success "PostgreSQL: $(psql --version | head -1)"
fi

# 检查PM2
if ! command -v pm2 &> /dev/null; then
    log_warning "PM2 未安装，尝试全局安装..."
    sudo npm install -g pm2
    log_success "PM2 安装完成"
else
    log_success "PM2: $(pm2 -v)"
fi

# 询问是否继续
log_step "部署配置确认"
read -p "是否继续部署？(y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    log_info "部署已取消"
    exit 0
fi

# ============================================
# 中国区域网络优化 (自动配置)
# ============================================
log_step "配置网络优化 (中国区域镜像)"

# 1. 设置 npm 镜像源
log_info "设置 npm 镜像源为淘宝镜像 (npmmirror.com)..."
npm config set registry https://registry.npmmirror.com
log_success "npm 镜像源已更新: $(npm config get registry)"

# 2. 优化 npm 配置 (禁用审计和资金检查，避免镜像源 404 错误)
log_info "禁用 npm audit 和 fund 检查..."
npm config set audit false
npm config set fund false
log_success "npm 基础配置已优化"

# 3. 设置 Prisma Engine 镜像源 (解决二进制下载失败)
log_info "设置 Prisma Engine 镜像源为 npmmirror..."
export PRISMA_ENGINES_MIRROR=https://registry.npmmirror.com/-/binary/prisma
log_success "PRISMA_ENGINES_MIRROR 已设置"

# 4. 设置 Playwright 镜像源 (如果需要)
export PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 # 默认跳过，生产环境通常不需要浏览器
# ============================================

# 清理npm缓存（解决模块解析问题）
log_step "清理npm缓存"
log_info "清理npm缓存以避免模块解析问题..."
npm cache clean --force
log_success "npm缓存已清理"

# 安装依赖函数（带回退机制和详细输出）
install_dependencies() {
    local app_name=$1
    local app_dir=$2
    
    log_info "安装 $app_name 依赖..."
    
    if [ -n "$app_dir" ]; then
        cd "$app_dir"
    fi
    
    # 尝试使用 npm ci（确定性安装）
    log_info "尝试使用 npm ci 安装..."
    if npm ci --verbose 2>&1 | tee /tmp/npm-ci-$app_name.log; then
        log_success "$app_name 依赖安装完成 (npm ci)"
    else
        log_warning "$app_name npm ci 失败，尝试使用 npm install..."
        log_info "删除 package-lock.json 以避免冲突..."
        rm -f package-lock.json
        
        log_info "开始 npm install（这可能需要几分钟，请耐心等待）..."
        log_info "如果长时间无响应，可以按 Ctrl+C 取消，然后运行 scripts/fix-ubuntu-prisma-deps.sh"
        
        # 使用 --verbose 显示详细进度，使用 --legacy-peer-deps 避免依赖冲突
        if npm install --verbose --legacy-peer-deps 2>&1 | tee /tmp/npm-install-$app_name.log; then
            log_success "$app_name 依赖安装完成 (npm install)"
        else
            log_error "$app_name 依赖安装失败"
            log_info "日志已保存到: /tmp/npm-install-$app_name.log"
            log_info "请检查网络连接和 npm 配置"
            if [ -n "$app_dir" ]; then
                cd ..
            fi
            return 1
        fi
    fi
    
    if [ -n "$app_dir" ]; then
        cd ..
    fi
    return 0
}

# 安装依赖
log_step "安装依赖"

# 主应用依赖
if ! install_dependencies "主应用" ""; then
    log_error "主应用依赖安装失败，部署终止"
    exit 1
fi

# H5应用依赖
if [ -d "h5-display-app" ] && [ -f "h5-display-app/package.json" ]; then
    install_dependencies "h5-display-app" "h5-display-app" || log_warning "h5-display-app 依赖安装失败，继续..."
else
    log_warning "h5-display-app 不存在，跳过"
fi

if [ -d "h5-proctor-app" ] && [ -f "h5-proctor-app/package.json" ]; then
    install_dependencies "h5-proctor-app" "h5-proctor-app" || log_warning "h5-proctor-app 依赖安装失败，继续..."
else
    log_warning "h5-proctor-app 不存在，跳过"
fi

if [ -d "h5-wework-app" ] && [ -f "h5-wework-app/package.json" ]; then
    install_dependencies "h5-wework-app" "h5-wework-app" || log_warning "h5-wework-app 依赖安装失败，继续..."
else
    log_warning "h5-wework-app 不存在，跳过"
fi

# 验证关键依赖
log_step "验证关键依赖"
log_info "检查 Prisma 依赖..."

if [ -d "node_modules/@prisma/client" ] && [ -d "node_modules/prisma" ]; then
    log_success "Prisma 依赖已安装"
    
    # 显示版本信息
    PRISMA_CLIENT_VERSION=$(npm list @prisma/client --depth=0 2>/dev/null | grep @prisma/client | awk -F@ '{print $NF}' || echo "未知")
    PRISMA_CLI_VERSION=$(npm list prisma --depth=0 2>/dev/null | grep prisma@ | awk -F@ '{print $NF}' || echo "未知")
    log_info "@prisma/client: $PRISMA_CLIENT_VERSION"
    log_info "prisma: $PRISMA_CLI_VERSION"
else
    log_error "Prisma 依赖未正确安装"
    log_info "尝试手动安装 Prisma..."
    npm install @prisma/client prisma
fi

# 检查环境变量
log_step "检查环境变量"

if [ ! -f ".env" ]; then
    log_warning ".env 文件不存在"
    if [ -f ".env.example" ]; then
        log_info "从 .env.example 创建 .env 文件..."
        cp .env.example .env
        log_warning "请编辑 .env 文件配置数据库连接等信息"
        log_info "编辑完成后，运行: nano .env"
        read -p "现在编辑 .env 文件？(y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            nano .env
        else
            log_warning "请稍后手动编辑 .env 文件"
            exit 0
        fi
    else
        log_error ".env.example 也不存在，请检查部署包"
        exit 1
    fi
else
    log_success ".env 文件已存在"
fi

# 数据库初始化
log_step "数据库初始化"

log_info "生成 Prisma Client..."
if npm run prisma:generate; then
    log_success "Prisma Client 生成完成"
else
    log_error "Prisma Client 生成失败"
    log_info "尝试诊断问题..."
    
    # 诊断信息
    log_info "检查 Prisma schema 文件..."
    if [ -f "db/prisma/schema.prisma" ]; then
        log_success "schema.prisma 文件存在"
    else
        log_error "schema.prisma 文件不存在"
    fi
    
    log_info "检查 node_modules..."
    if [ -d "node_modules" ]; then
        log_success "node_modules 目录存在"
        log_info "node_modules/@prisma/client: $([ -d 'node_modules/@prisma/client' ] && echo '存在' || echo '不存在')"
        log_info "node_modules/prisma: $([ -d 'node_modules/prisma' ] && echo '存在' || echo '不存在')"
        log_info "node_modules/c12: $([ -d 'node_modules/c12' ] && echo '存在' || echo '不存在')"
    else
        log_error "node_modules 目录不存在"
    fi
    
    log_error "请检查上述诊断信息，手动修复后重新运行部署脚本"
    exit 1
fi

read -p "是否需要推送数据库schema？(y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log_info "推送数据库schema..."
    if npm run prisma:push; then
        log_success "数据库schema推送完成"
    else
        log_error "数据库schema推送失败"
        log_warning "报错 P2002? 这通常是因为数据库中存在重复数据，违反了新的唯一性约束(JobType/JobSubject)。"
        read -p "是否尝试强制重置数据库(数据将丢失，并重新创建)？(y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            log_info "强制重置数据库..."
            npx prisma db push --schema db/prisma/schema.prisma --force-reset
            log_success "数据库强制重置并同步完成"
        else
            log_error "请手动清理数据库冲突数据后重试"
            exit 1
        fi
    fi

    read -p "是否需要初始化种子数据？(y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        log_info "初始化种子数据..."
        npm run seed
        npm run seed:exam-structure
        log_success "种子数据初始化完成"
    fi
fi

# 构建应用
log_step "构建应用"

log_info "构建主应用..."
npm run build
log_success "主应用构建完成"

if [ -d "h5-display-app" ] && [ -f "h5-display-app/package.json" ]; then
    log_info "构建 h5-display-app..."
    cd h5-display-app && npm run build && cd ..
    log_success "h5-display-app 构建完成"
fi

if [ -d "h5-proctor-app" ] && [ -f "h5-proctor-app/package.json" ]; then
    log_info "构建 h5-proctor-app..."
    cd h5-proctor-app && npm run build && cd ..
    log_success "h5-proctor-app 构建完成"
fi

if [ -d "h5-wework-app" ] && [ -f "h5-wework-app/package.json" ]; then
    log_info "构建 h5-wework-app..."
    cd h5-wework-app && npm run build && cd ..
    log_success "h5-wework-app 构建完成"
fi

# 创建日志目录
log_step "创建日志目录"
mkdir -p logs
log_success "日志目录创建完成"

# 启动应用
log_step "启动应用"

log_info "使用PM2启动所有应用..."

# 检查是否已有应用在运行
if pm2 list | grep -q "exmam-register"; then
    log_info "检测到应用已在运行，执行重启..."
    pm2 restart ecosystem.config.js
    log_success "应用已重启"
else
    log_info "首次启动应用..."
    pm2 start ecosystem.config.js
    log_success "应用已启动"
fi

# 显示状态
log_step "应用状态"
pm2 status

# 设置开机自启
log_step "配置开机自启"
read -p "是否配置PM2开机自启？(y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    pm2 save
    pm2 startup
    log_warning "请执行上面输出的 sudo 命令以完成开机自启配置"
fi

# 完成
echo ""
echo "========================================"
echo "  部署完成！"
echo "========================================"
echo ""
echo "应用访问地址："
echo "  - 主应用（管理后台）: http://localhost:3000"
echo "  - 显示屏H5: http://localhost:3002"
echo "  - 企业微信H5: http://localhost:5173"
echo "  - 监考H5: http://localhost:5174"
echo ""
echo "PM2管理命令："
echo "  - 查看状态: pm2 status"
echo "  - 查看日志: pm2 logs"
echo "  - 重启应用: pm2 restart all"
echo "  - 停止应用: pm2 stop all"
echo ""
echo "详细文档："
echo "  - 迁移指南: MIGRATION_GUIDE.md"
echo ""
echo "故障排除："
echo "  如遇 Prisma 依赖问题，请运行:"
echo "  1. rm -rf node_modules package-lock.json"
echo "  2. npm cache clean --force"
echo "  3. npm install"
echo "  4. npm run prisma:generate"
echo ""
