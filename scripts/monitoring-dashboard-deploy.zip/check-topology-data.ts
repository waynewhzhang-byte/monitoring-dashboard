import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const viewName = '出口业务';
  console.log(`🔍 Checking data for view: "${viewName}"`);
  
  const nodes = await prisma.topologyNode.count({ where: { viewName } });
  const edges = await prisma.topologyEdge.count({ where: { viewName } });
  const config = await prisma.businessViewConfig.findUnique({ where: { name: viewName } });
  
  console.log(`📊 Nodes: ${nodes}`);
  console.log(`📊 Edges: ${edges}`);
  console.log(`⚙️ Config: ${config ? 'Found' : 'NOT Found'}`);
  
  if (config) {
    console.log(`📷 Camera: X=${config.cameraX}, Y=${config.cameraY}, Zoom=${config.cameraZoom}`);
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
